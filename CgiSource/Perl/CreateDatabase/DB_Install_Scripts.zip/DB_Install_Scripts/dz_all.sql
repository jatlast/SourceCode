PRINT 'Netik Interchange 2.3 OLTP day zero'
PRINT 'Dropping existing views...'

DROP VIEW DS_V_FieldInApp
DROP VIEW DS_V_FieldMap
DROP VIEW DS_V_FieldMapName
DROP VIEW DS_V_FieldInView
DROP VIEW DS_V_PropertyInSet
DROP VIEW DS_V_ItemInMenu

PRINT 'Dropping existing stored procedures...'

DROP PROCEDURE DS_P_DeleteApp

PRINT 'Dropping existing tables...'

ALTER TABLE [dbo].[DS_PropertySet] DROP CONSTRAINT FK_DSDefaultProperty
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DS_ServiceRequest]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DS_ServiceRequest]
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DS_FieldMapItem]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DS_FieldMapItem]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DS_FieldMap]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DS_FieldMap]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DS_FieldClass]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DS_FieldClass]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DS_FormField]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DS_FormField]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DS_FieldInView]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DS_FieldInView]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DS_Property]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DS_Property]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DS_PropertySet]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DS_PropertySet]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DS_View]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DS_View]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DS_Field]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DS_Field]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DS_Application]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DS_Application]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DS_MenuItem]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DS_MenuItem]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DS_Menu]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DS_Menu]
GO

PRINT 'Deleting user defined types..'
SET NOCOUNT ON
if exists (select * from systypes where name = 'T_NtkDescription')
EXEC sp_droptype 'T_NtkDescription'
GO

SET NOCOUNT ON
if exists (select * from systypes where name = 'T_NtkFieldName')
EXEC sp_droptype 'T_NtkFieldName'
GO

if exists (select * from systypes where name = 'T_NtkLongName')
EXEC sp_droptype 'T_NtkLongName'
GO

if exists (select * from systypes where name = 'T_NtkName')
EXEC sp_droptype 'T_NtkName'
GO

if exists (select * from systypes where name = 'T_NtkStringId')
EXEC sp_droptype 'T_NtkStringId'
GO

if exists (select * from systypes where name = 'T_NtkIdentifier')
EXEC sp_droptype 'T_NtkIdentifier'
GO

if exists (select * from systypes where name = 'T_NtkUrl')
EXEC sp_droptype 'T_NtkUrl'
GO


PRINT 'Creating user defined types...'

setuser 'dbo'
GO

PRINT '..T_NtkDescription'

if not exists (select * from systypes where name = 'T_NtkDescription')
EXEC sp_addtype 'T_NtkDescription', 'varchar (100)', 'null'
GO

PRINT '..T_NtkFieldName'

if not exists (select * from systypes where name = 'T_NtkFieldName')
EXEC sp_addtype 'T_NtkFieldName', 'varchar (64)', 'null'
GO

PRINT '..T_NtkLongName'
if not exists (select * from systypes where name = 'T_NtkLongName')
EXEC sp_addtype 'T_NtkLongName', 'varchar (50)', 'not null'
GO

PRINT '..T_NtkName'
if not exists (select * from systypes where name = 'T_NtkName')
EXEC sp_addtype 'T_NtkName', 'varchar (32)', 'not null'
GO

PRINT '..T_NtkStringId'

if not exists (select * from systypes where name = 'T_NtkStringId')
EXEC sp_addtype 'T_NtkStringId', 'char (36)', 'not null'
GO

PRINT '..T_NtkIdentifier'
if not exists (select * from systypes where name = 'T_NtkIdentifier')
EXEC sp_addtype 'T_NtkIdentifier', 'uniqueidentifier', 'not null'
GO

PRINT '..T_NtkUrl'
if not exists (select * from systypes where name = 'T_NtkUrl')
EXEC sp_addtype 'T_NtkUrl', 'varchar (255)', 'null'
GO

PRINT 'Creating tables...'

PRINT '..DS_Application'

CREATE TABLE [dbo].[DS_Application] (
	[DSApplication_Id] [T_NtkStringId] PRIMARY KEY,
	[GT_PfsEntry] [T_NtkStringId] NULL ,
	[Name] [T_NtkName] NOT NULL ,
	[Description] [T_NtkDescription] NULL ,
	[TemplateName] [T_NtkDescription] NULL ,
	[TimeStamp] [datetime] NULL
	CONSTRAINT [IX_UQ_AppName] UNIQUE  NONCLUSTERED 
	(
		[Name]
	), 
) ON [PRIMARY]
GO

PRINT '..DS_Field'

CREATE TABLE [dbo].[DS_Field] (
	[DSField_Id] [T_NtkStringId] PRIMARY KEY,
	[DSApplication_Id] [T_NtkStringId] FOREIGN KEY REFERENCES DS_Application,
	[Name] [T_NtkFieldName] NOT NULL ,
	[Description] [T_NtkDescription] NULL ,
	[Length] [smallint] NOT NULL ,
	[KeyPos] [smallint] NOT NULL ,
	[GtField_Id] [T_NtkStringId] NULL 
	CONSTRAINT [IX_UQ_AppField] UNIQUE  NONCLUSTERED 
	(
		[DSApplication_Id],
		[Name]
	),
) ON [PRIMARY]
GO

PRINT '..DS_View'

CREATE TABLE [dbo].[DS_View] (
	[DSView_Id] [T_NtkStringId] PRIMARY KEY,
	[DSApplication_Id] [T_NtkStringId] FOREIGN KEY REFERENCES DS_Application,
	[Name] [T_NtkName] NOT NULL ,
	[Description] [T_NtkDescription] NULL ,
	[Type] [smallint] NOT NULL ,
	CONSTRAINT [IX_UQ_ViewType] UNIQUE  NONCLUSTERED 
	(
		[DSApplication_Id],
		[Type]
	),
	CONSTRAINT [CK_DSView] CHECK ([Type] = 2 or [Type] = 1)
) ON [PRIMARY]
GO

PRINT '..DS_FieldInView'

CREATE TABLE [dbo].[DS_FieldInView] (
	[DSFieldInView_Id] [T_NtkStringId] PRIMARY KEY,
	[DSView_Id] [T_NtkStringId] FOREIGN KEY REFERENCES DS_View,
	[DSField_Id] [T_NtkStringId] FOREIGN KEY REFERENCES DS_Field,
	[Type] [smallint] NOT NULL ,
	[Label] [T_NtkDescription] NULL ,
	[DisplayOrder] [smallint] NOT NULL ,
	[LinkType] [smallint] NULL ,
	[Width] [smallint] NOT NULL ,
	[Height] [smallint] NOT NULL ,
	[IsVisible] [bit] NOT NULL ,
	[DsPropertySet_Id] [T_NtkStringId] NULL 
) ON [PRIMARY]
GO

PRINT '..DS_FieldClass'

CREATE TABLE [dbo].[DS_FieldClass] (
	[DSFieldInView_Id] [T_NtkStringId] FOREIGN KEY REFERENCES DS_FieldInView ,
	[Name] [T_NtkName] NOT NULL 
) ON [PRIMARY]
GO

PRINT '..DS_FieldMap'

CREATE TABLE [dbo].[DS_FieldMap] (
	[DSFieldMap_Id] [T_NtkStringId] PRIMARY KEY,
	[DSApplication_Id] [T_NtkStringId] FOREIGN KEY REFERENCES DS_Application,
	[DsToApplication_Id] [T_NtkStringId] FOREIGN KEY REFERENCES DS_Application,
	[Name] [T_NtkName] NOT NULL ,
	[Description] [T_NtkDescription] NULL ,
	[DSField_Id] [T_NtkStringId] NULL ,
	[StatusField_Id] [T_NtkStringId] NULL
	CONSTRAINT [IX_UQ_FieldMapName] UNIQUE  NONCLUSTERED 
	(
		[DSApplication_Id],
		[Name]
	) 
) ON [PRIMARY]
GO

PRINT '..DS_FieldMapItem'

CREATE TABLE [dbo].[DS_FieldMapItem] (
	[DsFieldMapItem_Id] [T_NtkStringId] PRIMARY KEY,
	[DsFieldMap_Id] [T_NtkStringId] FOREIGN KEY REFERENCES DS_FieldMap,
	[LocalField_Id] [T_NtkStringId] FOREIGN KEY REFERENCES DS_Field,
	[ForeignField_Id] [T_NtkStringId] FOREIGN KEY REFERENCES DS_Field,
	[Direction] [smallint] NOT NULL ,
	[FireEvent] [smallint] NOT NULL,
	CONSTRAINT [IX_DSFieldMapItem] UNIQUE  NONCLUSTERED 
	(
		[DsFieldMap_Id],
		[LocalField_Id],
		[ForeignField_Id],
		[Direction]
	)
) ON [PRIMARY]
GO

PRINT '..DS_FormField'

CREATE TABLE [dbo].[DS_FormField] (
	[DsFieldInView_Id] [T_NtkStringId] FOREIGN KEY REFERENCES DS_FieldInView,
	[Tabstop] [smallint] NULL ,
	[IsEnabled] [bit] NOT NULL ,
	[Flags] [int] NOT NULL,
	CONSTRAINT [IX_UQ_FormField] UNIQUE  NONCLUSTERED 
	(
		[DsFieldInView_Id]
	),
) ON [PRIMARY]
GO

PRINT '..DS_Menu'

CREATE TABLE [dbo].[DS_Menu] (
	[DSMenu_Id] [T_NtkStringId] PRIMARY KEY,
	[Name] [T_NtkName] NOT NULL ,
	[Description] [T_NtkDescription] NULL 
) ON [PRIMARY]
GO

PRINT '..DS_MenuItem'

CREATE TABLE [dbo].[DS_MenuItem] (
	[DSMenuItem_Id] [T_NtkStringId] PRIMARY KEY,
	[DSMenu_Id] [T_NtkStringId] FOREIGN KEY REFERENCES DS_Menu,
	[DisplayOrder] [smallint] NOT NULL ,
	[Name] [T_NtkName] NOT NULL ,
	[Description] [T_NtkDescription] NULL ,
	[URL] [T_NtkUrl] NULL ,
	[Parent_Id] [T_NtkStringId] NULL FOREIGN KEY REFERENCES DS_MenuItem
) ON [PRIMARY]
GO

PRINT '..DS_PropertySet'

CREATE TABLE [dbo].[DS_PropertySet] (
	[DsPropertySet_Id] [T_NtkStringId] PRIMARY KEY,
	[Name] [T_NtkName] NOT NULL ,
	[Description] [T_NtkDescription] NULL ,
	[DSDefaultProperty_Id] [T_NtkStringId] NULL
) ON [PRIMARY]
GO

PRINT '..DS_Property'

CREATE TABLE [dbo].[DS_Property] (
	[DsProperty_Id] [T_NtkStringId] PRIMARY KEY,
	[DsPropertySet_Id] [T_NtkStringId] NULL FOREIGN KEY REFERENCES DS_PropertySet,
	[name] [T_NtkLongName] NOT NULL ,
	[value] [T_NtkLongName] NULL
	CONSTRAINT [IX_UQ_PropertyName] UNIQUE  NONCLUSTERED 
	(
		[DsPropertySet_Id],
		[name]
	) 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[DS_PropertySet] WITH NOCHECK ADD 
	CONSTRAINT [FK_DSDefaultProperty] FOREIGN KEY 
	(
		[DSDefaultProperty_Id]
	) REFERENCES [dbo].[DS_Property] (
		[DsProperty_Id]
	)
GO

PRINT '..DS_ServiceRequest'

CREATE TABLE [dbo].[DS_ServiceRequest] (
	[DSFormFieldInView_Id] [T_NtkStringId] FOREIGN KEY REFERENCES DS_FieldInView,
	[DSFieldMap_Id] [T_NtkStringId] FOREIGN KEY REFERENCES DS_FieldMap ,
	[EventType] [smallint] NOT NULL ,
	[RequestType] [smallint] NOT NULL ,
	[DSView_Id] [T_NtkStringId] NULL FOREIGN KEY REFERENCES DS_View
	CONSTRAINT [PK_DS_ServiceRequest] PRIMARY KEY  NONCLUSTERED 
	(
		[DSFormFieldInView_Id],
		[DSFieldMap_Id]
	)
) ON [PRIMARY]
GO

PRINT 'Creating views...'
PRINT '..DS_V_FieldInApp'
GO
CREATE VIEW dbo.DS_V_FieldInApp
AS
SELECT DS_Application.DSApplication_Id, DS_Field.DSField_Id, 
    DS_Application.Name AS AppName, DS_Application.TemplateName,
    DS_Field.Name AS FldName, DS_Field.Length, DS_Field.KeyPos, DS_Field.GtField_Id, 
    DS_Application.GT_PfsEntry
FROM DS_Application LEFT OUTER JOIN
    DS_Field ON 
    DS_Application.DSApplication_Id = DS_Field.DSApplication_Id

GO

PRINT '..DS_V_FieldMap'
GO
CREATE VIEW dbo.DS_V_FieldMap
AS
SELECT DS_FieldMap.DSFieldMap_Id, 
    DS_FieldMap.DSApplication_Id, 
    DS_FieldMap.Name AS MapName,
    DS_FieldMap.DsToApplication_Id, 
    DS_FieldMap.DsField_Id As QualifierField,
    DS_FieldMap.StatusField_Id,
    DS_FieldMapItem.DsFieldMapItem_Id, 
    DS_FieldMapItem.LocalField_Id, 
    DS_FieldMapItem.ForeignField_Id, 
    DS_FieldMapItem.Direction,
    DS_FieldMapItem.FireEvent
FROM DS_FieldMap LEFT OUTER JOIN
    DS_FieldMapItem ON 
    DS_FieldMap.DSFieldMap_Id = DS_FieldMapItem.DsFieldMap_Id

GO

PRINT '..DS_V_FieldMapName'
GO
CREATE VIEW dbo.DS_V_FieldMapName
AS
SELECT DS_FieldMap.Name AS MapName, 
    DS_FieldMapItem.DsFieldMapItem_Id, 
    DS_Field.Name AS Local, DS_Field1.Name AS Server, 
    DS_FieldMapItem.Direction,
    DS_FieldMapItem.FireEvent
FROM DS_Field INNER JOIN
    DS_FieldMapItem ON 
    DS_Field.DSField_Id = DS_FieldMapItem.LocalField_Id INNER JOIN
    DS_Field DS_Field1 ON 
    DS_FieldMapItem.ForeignField_Id = DS_Field1.DSField_Id LEFT
     OUTER JOIN
    DS_FieldMap ON 
    DS_FieldMapItem.DsFieldMap_Id = DS_FieldMap.DSFieldMap_Id

GO

PRINT '..DS_V_FieldInView'
GO
CREATE VIEW dbo.DS_V_FieldInView
AS
SELECT DS_View.DSView_Id, DS_View.DSApplication_Id, 
    DS_View.Name AS ViewName, DS_View.Type AS ViewType, DS_View.Description AS ViewDescription, 
    DS_FieldInView.DSFieldInView_Id, 
    DS_FieldInView.DSField_Id,  
    DS_FieldInView.Type AS FldType, DS_FieldInView.Label, 
    DS_FieldInView.DisplayOrder, DS_FieldInView.LinkType, 
    DS_FieldInView.Width, DS_FieldInView.Height, 
    DS_FieldInView.IsVisible, DS_FormField.Tabstop, 
    DS_FormField.IsEnabled,
    DS_FormField.Flags, DS_ServiceRequest.DSFieldMap_Id, 
    DS_ServiceRequest.EventType, DS_ServiceRequest.RequestType,
    DS_ServiceRequest.DSView_Id As RequestView, DS_FieldInView.DSPropertySet_Id, DS_FieldClass.Name AS ClassName
FROM DS_FieldInView INNER JOIN
    DS_View ON 
    DS_FieldInView.DSView_Id = DS_View.DSView_Id 
    LEFT OUTER JOIN DS_ServiceRequest ON 
    DS_FieldInView.DSFieldInView_Id = DS_ServiceRequest.DSFormFieldInView_Id
    LEFT OUTER JOIN DS_FormField ON 
    DS_FieldInView.DSFieldInView_Id = DS_FormField.DsFieldInView_Id
    LEFT OUTER JOIN DS_FieldClass ON
    DS_FieldInView.DSFieldInView_Id = DS_FieldClass.DsFieldInView_Id
GO

PRINT '..DS_V_PropertyInSet'
GO
CREATE VIEW dbo.DS_V_PropertyInSet
AS
SELECT DS_PropertySet.DsPropertySet_Id, 
    DS_PropertySet.Name AS SetName, DS_PropertySet.DsDefaultProperty_Id,
    DS_Property.DsProperty_Id, DS_Property.name, 
    DS_Property.value
FROM DS_Property RIGHT OUTER JOIN
    DS_PropertySet ON 
    DS_Property.DsPropertySet_Id = DS_PropertySet.DsPropertySet_Id

GO

PRINT '..DS_V_ItemInMenu'
GO
CREATE VIEW dbo.DS_V_ItemInMenu
AS
SELECT DS_Menu.DSMenu_Id, DS_Menu.Name AS MenuName, 
    DS_MenuItem.DSMenuItem_Id, DS_MenuItem.DisplayOrder, 
    DS_MenuItem.Name AS ItemName, DS_MenuItem.Description, 
    DS_MenuItem.URL, DS_MenuItem.Parent_Id
FROM DS_Menu INNER JOIN
    DS_MenuItem ON 
    DS_Menu.DSMenu_Id = DS_MenuItem.DSMenu_Id
GO

PRINT 'Creating stored procedures...'
PRINT '..DS_P_DeleteApp'
GO
CREATE PROCEDURE DS_P_DeleteApp @appId char(36) AS
BEGIN

DELETE FROM DS_ServiceRequest
WHERE DsFormFieldInView_Id  IN (
SELECT fmff.DSFormFieldInView_Id
 FROM DS_ServiceRequest fmff, DS_FieldMap fm
 WHERE
	fmff.DSFieldMap_Id = fm.DSFieldMap_Id
   AND ( fm.DSApplication_Id = @appId
    OR fm.DSToApplication_Id = @appId ) )

DELETE
   FROM DS_FieldMapItem
WHERE DSFieldMap_Id IN (
SELECT DSFieldMap_Id 
FROM  DS_FieldMap fm
WHERE  fm.DSApplication_Id = @appId
 OR fm.DSToApplication_Id = @appId )

DELETE FROM DS_FieldMap
WHERE DSApplication_Id = @AppId
 OR DSToApplication_Id = @appId

DELETE FROM DS_FormField
WHERE DsFieldInView_Id IN
( SELECT ff.DsFieldInView_Id
     FROM DS_FormField ff, DS_FieldInView fiv, DS_View v
 WHERE ff.DsFieldInView_Id = fiv.DsFieldInView_Id
      AND fiv.DsView_Id = v.DSView_Id
      AND v.DsApplication_Id = @AppId )

DELETE FROM DS_FieldClass
WHERE DsFieldInView_Id IN
( SELECT fc.DsFieldInView_Id
     FROM DS_FieldClass fc, DS_FieldInView fiv, DS_View v
 WHERE fc.DsFieldInView_Id = fiv.DsFieldInView_Id
      AND fiv.DsView_Id = v.DSView_Id
      AND v.DsApplication_Id = @AppId )

DELETE DS_FieldInView
 FROM DS_FieldInView fiv, DS_View v
 WHERE fiv.DsView_Id = v.DSView_Id
      AND v.DsApplication_Id = @AppId

DELETE
FROM DS_View
WHERE DsApplication_Id = @AppId

DELETE
FROM DS_Field
WHERE  DsApplication_Id = @AppId

DELETE
FROM DS_Application
WHERE  DsApplication_Id = @AppId
END
GO






PRINT 'Netik Interchange 2.3 Foreman day zero'
PRINT 'Dropping existing tables...'

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_ActiveEventSet]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_ActiveEventSet]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_ActiveEventSetClassMap]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_ActiveEventSetClassMap]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_ActiveEventSetState]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_ActiveEventSetState]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_EventAction]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_EventAction]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_EventClass]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_EventClass]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_EventClassParam]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_EventClassParam]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_EventClassTaskSetMap]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_EventClassTaskSetMap]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_EventConcurrency]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_EventConcurrency]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_EventGroup]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_EventGroup]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_EventQueue]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_EventQueue]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_EventQueueEventStateHistory]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_EventQueueEventStateHistory]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_EventSet]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_EventSet]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_EventSetClassMap]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_EventSetClassMap]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_EventState]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_EventState]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_EventStateAction]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_EventStateAction]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_EventStateActionMap]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_EventStateActionMap]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_TaskClass]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_TaskClass]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_TaskClassParam]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_TaskClassParam]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_TaskParamMap]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_TaskParamMap]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_TaskQueue]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_TaskQueue]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_TaskSet]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_TaskSet]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_TaskSetClassMap]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_TaskSetClassMap]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_TaskState]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_TaskState]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FM_TaskType]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FM_TaskType]
GO

PRINT 'Creating tables...'

PRINT '..FM_ActiveEventSet'

CREATE TABLE [dbo].[FM_ActiveEventSet] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[ActiveEventSetId] [int] PRIMARY KEY CLUSTERED,
	[EventSetRef] [varchar] (50) NOT NULL ,
	[ActiveEventSetStateId] [int] NOT NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT '..FM_ActiveEventSetClassMap'

CREATE TABLE [dbo].[FM_ActiveEventSetClassMap] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[ActiveEventSetId] [int] NOT NULL ,
	[EventRef] [varchar] (50) NOT NULL ,
	[EventSetClassMapSeq] [int] NOT NULL ,
	[CaptureSeq] [int] NOT NULL ,
	[CaptureDateTime] [datetime] NOT NULL ,
	[EventOrder] [int] NOT NULL ,
	[TriggerStartProcessingSet] [tinyint] NULL ,
	[TriggerStopProcessingSet] [tinyint] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL,
        PRIMARY KEY CLUSTERED(	[ActiveEventSetId], [EventRef],	[EventSetClassMapSeq])

) ON [PRIMARY]
GO

PRINT '..FM_ActiveEventSetState'

CREATE TABLE [dbo].[FM_ActiveEventSetState] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[ActiveEventSetStateId] [varchar] (50) PRIMARY KEY CLUSTERED,
	[ActiveEventSetStateName] [varchar] (50) NOT NULL ,
	[ActiveEventSetStateDesc] [varchar] (255) NOT NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT '..FM_EventAction'

CREATE TABLE [dbo].[FM_EventAction] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[EventActionId] [int] PRIMARY KEY CLUSTERED,
	[EventActionName] [varchar] (50) NOT NULL ,
	[EventActionDesc] [varchar] (255) NOT NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT '..FM_EventClass'

CREATE TABLE [dbo].[FM_EventClass] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[EventClassRef] [varchar] (50) PRIMARY KEY CLUSTERED,
	[EventClassDesc] [varchar] (255) NOT NULL ,
	[EventGroupRef] [varchar] (50) NULL ,
	[EventConcurrencyRef] [varchar] (50) NOT NULL ,
	[DefaultEventStateId] [int] NOT NULL ,
	[DefaultEventPriority] [int] NOT NULL ,
	[DefaultEventActionId] [int] NOT NULL ,
	[SuppressOperatorAlert] [tinyint] NOT NULL ,
	[KeepEventStateHistory] [tinyint] NOT NULL ,
	[UsesEventSet] [tinyint] NOT NULL ,
	[ActiveFrom] [datetime] NULL ,
	[ActiveTo] [datetime] NULL ,
	[ArchiveOption] [int] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[MaxConcurrentCount] [int] NULL ,
	[EventAttributes] [int] NULL 
) ON [PRIMARY]
GO

PRINT '..FM_EventClassParam'

CREATE TABLE [dbo].[FM_EventClassParam] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[EventClassRef] [varchar] (50) NOT NULL ,
	[EventClassParamRef] [varchar] (50) NOT NULL ,
	[EventClassParamDesc] [varchar] (255) NOT NULL ,
	[DefaultParamOrder] [int] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL,
	PRIMARY KEY CLUSTERED( [EventClassRef],	[EventClassParamRef] )
) ON [PRIMARY]
GO

PRINT '..FM_EventClassTaskSetMap'

CREATE TABLE [dbo].[FM_EventClassTaskSetMap] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[EventClassRef] [varchar] (50) NOT NULL ,
	[TaskSetRef] [varchar] (50) NOT NULL ,
	[MapOrder] [int] NOT NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL
	PRIMARY KEY CLUSTERED (	[EventClassRef], [TaskSetRef]  )
) ON [PRIMARY]
GO

PRINT '..FM_EventConcurrency'

CREATE TABLE [dbo].[FM_EventConcurrency] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[EventConcurrencyRef] [varchar] (50) PRIMARY KEY CLUSTERED,
	[EventConcurrencyDesc] [varchar] (255) NOT NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT '..FM_EventGroup'

CREATE TABLE [dbo].[FM_EventGroup] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[EventGroupRef] [varchar] (50) PRIMARY KEY CLUSTERED,
	[EventGroupDesc] [varchar] (255) NOT NULL ,
	[ParentEventGroupRef] [varchar] (50) NULL ,
	[ParentRelationshipDesc] [varchar] (255) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT '..FM_EventQueue'

CREATE TABLE [dbo].[FM_EventQueue] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[EventRef] [varchar] (50) PRIMARY KEY CLUSTERED,
	[EventClassRef] [varchar] (50) NOT NULL ,
	[EventActionId] [int] NOT NULL ,
	[EventPriority] [int] NOT NULL ,
	[EventStateId] [int] NOT NULL ,
	[EventDateTime] [datetime] NOT NULL ,
	[EventNotifyDateTime] [datetime] NULL ,
	[ParentEventRef] [varchar] (50) NULL ,
	[EventParamString] [text] NULL ,
	[EventSource] [varchar] (50) NULL ,
	[EventSourceInstance] [varchar] (50) NULL ,
	[ActiveFrom] [datetime] NULL ,
	[ActiveTo] [datetime] NULL ,
	[LastUpdateTime] [datetime] NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

PRINT '..FM_EventQueueEventStateHistory'

CREATE TABLE [dbo].[FM_EventQueueEventStateHistory] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[EventRef] [varchar] (50) NOT NULL ,
	[EventStateSeq] [int] NOT NULL ,
	[EventStateId] [int] NOT NULL ,
	[EventStateDateTime] [datetime] NOT NULL
        PRIMARY KEY CLUSTERED ( [EventRef], [EventStateSeq] )
) ON [PRIMARY]
GO

PRINT '..FM_EventSet'

CREATE TABLE [dbo].[FM_EventSet] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[EventSetRef] [varchar] (50) PRIMARY KEY CLUSTERED,
	[EventSetDesc] [varchar] (255) NOT NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT '..FM_EventSetClassMap'

CREATE TABLE [dbo].[FM_EventSetClassMap] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[EventClassRef] [varchar] (50) NOT NULL ,
	[EventSetRef] [varchar] (50) NOT NULL ,
	[EventSetClassMapSeq] [int] NOT NULL ,
	[EventOrder] [int] NOT NULL ,
	[TriggerStartProcessingSet] [tinyint] NULL ,
	[TriggerStopProcessingSet] [tinyint] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	PRIMARY KEY CLUSTERED ( [EventSetRef], [EventClassRef], [EventSetClassMapSeq])
) ON [PRIMARY]
GO

PRINT '..FM_EventState'

CREATE TABLE [dbo].[FM_EventState] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[EventStateId] [int] PRIMARY KEY CLUSTERED,
	[EventStateName] [varchar] (50) NOT NULL ,
	[EventStateDesc] [varchar] (255) NOT NULL ,
	[EventStateOrder] [int] NULL ,
	[FurtherProcessing] [tinyint] NULL ,
	[OperatorAlert] [tinyint] NULL ,
	[ValidInitialState] [tinyint] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[IsArchive] [int] NULL 
) ON [PRIMARY]
GO

PRINT '..FM_EventStateAction'

CREATE TABLE [dbo].[FM_EventStateAction] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[EventStateActionRef] [varchar] (50) PRIMARY KEY CLUSTERED,
	[EventStateActionDesc] [varchar] (255) NOT NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT '..FM_EventStateActionMap'

CREATE TABLE [dbo].[FM_EventStateActionMap] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[EventClassRef] [varchar] (50) NOT NULL ,
	[EventStateId] [int] NOT NULL ,
	[EventStateActionRef] [varchar] (50) NOT NULL ,
	[ActiveEventStateThreshold] [int] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL,
	PRIMARY KEY CLUSTERED ( [EventClassRef], [EventStateId] )
) ON [PRIMARY]
GO

PRINT '..FM_TaskClass'

CREATE TABLE [dbo].[FM_TaskClass] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[TaskClassRef] [varchar] (50) PRIMARY KEY CLUSTERED,
	[TaskClassDesc] [varchar] (255) NOT NULL ,
	[TaskTypeRef] [varchar] (50) NOT NULL ,
	[TaskProgId] [varchar] (100) NOT NULL ,
	[PersistentTask] [tinyint] NOT NULL ,
	[ProcessSingleTaskOnly] [tinyint] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[MaxInstanceCount] [int] NULL ,
	[DefaultAckTimeout] [int] NULL ,
	[MaxInstanceUsage] [int] NULL 
) ON [PRIMARY]
GO

PRINT '..FM_TaskClassParam'

CREATE TABLE [dbo].[FM_TaskClassParam] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[TaskClassRef] [varchar] (50) NOT NULL ,
	[TaskClassParamRef] [varchar] (50) NOT NULL ,
	[TaskClassParamDesc] [varchar] (255) NOT NULL ,
	[DefaultParamOrder] [int] NULL ,
	[DefaultValue] [varchar] (255) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	PRIMARY KEY CLUSTERED ( [TaskClassRef], [TaskClassParamRef] )
) ON [PRIMARY]
GO

PRINT '..FM_TaskParamMap'

CREATE TABLE [dbo].[FM_TaskParamMap] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[TaskParamMapRef] [varchar] (50) NOT NULL ,
	[TaskClassParamRef] [varchar] (50) NOT NULL ,
	[ConstantValue] [varchar] (255) NULL ,
	[MapOption] [int] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL
	PRIMARY KEY CLUSTERED ( [TaskParamMapRef], [TaskClassParamRef] )
) ON [PRIMARY]
GO

PRINT '..FM_TaskQueue'

CREATE TABLE [dbo].[FM_TaskQueue] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[TaskRef] [varchar] (50) PRIMARY KEY CLUSTERED,
	[TaskStateId] [int] NOT NULL ,
	[EventRef] [varchar] (50) NOT NULL ,
	[EventActionId] [int] NOT NULL ,
	[EventPriority] [int] NOT NULL ,
	[EventDateTime] [datetime] NOT NULL ,
	[TaskSetRef] [varchar] (50) NOT NULL ,
	[TaskClassRef] [varchar] (50) NOT NULL ,
	[TaskSeq] [int] NOT NULL ,
	[TaskOrder] [int] NOT NULL ,
	[ActiveTaskSetId] [int] NOT NULL ,
	[TaskClassInstanceId] [int] NULL ,
	[StartDateTime] [datetime] NULL ,
	[EndDateTime] [datetime] NULL ,
	[ParentTaskRef] [varchar] (50) NULL ,
	[TaskParamString] [text] NULL ,
	[InfoParamString] [text] NULL ,
	[LastUpdateTime] [datetime] NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

PRINT '..FM_TaskSet'

CREATE TABLE [dbo].[FM_TaskSet] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[TaskSetRef] [varchar] (50) PRIMARY KEY CLUSTERED,
	[TaskSetDesc] [varchar] (255) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT '..FM_TaskSetClassMap'

CREATE TABLE [dbo].[FM_TaskSetClassMap] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[TaskSetRef] [varchar] (50) NOT NULL ,
	[TaskClassRef] [varchar] (50) NOT NULL ,
	[TaskSeq] [int] NOT NULL ,
	[TaskOrder] [int] NOT NULL ,
	[TaskClassInstanceDesc] [varchar] (255) NOT NULL ,
	[TaskParamMapRef] [varchar] (50) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL
	PRIMARY KEY CLUSTERED (	[TaskSetRef], [TaskSeq] )
) ON [PRIMARY]
GO

PRINT '..FM_TaskState'

CREATE TABLE [dbo].[FM_TaskState] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[TaskStateId] [int] PRIMARY KEY CLUSTERED,
	[TaskStateName] [varchar] (50) NOT NULL ,
	[TaskStateDesc] [varchar] (255) NOT NULL ,
	[TaskStateOrder] [int] NULL ,
	[OperatorAlert] [tinyint] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT '..FM_TaskType'

CREATE TABLE [dbo].[FM_TaskType] (
	[NtkObjectId] [varchar] (50) NOT NULL ,
	[TaskTypeRef] [varchar] (50) PRIMARY KEY CLUSTERED,
	[TaskTypeDesc] [varchar] (255) NOT NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT 'Creating indexes...'

PRINT '..IX_FM_EventQueue_1'

CREATE  INDEX [IX_FM_EventQueue_1] ON [dbo].[FM_EventQueue]([EventStateId], [EventPriority]) ON [PRIMARY]
GO

PRINT '..IX_FM_TaskQueue_1'

CREATE  INDEX [IX_FM_TaskQueue_1] ON [dbo].[FM_TaskQueue]([TaskStateId], [EventPriority]) ON [PRIMARY]
GO

PRINT '..IX_FM_TaskQueue_2'

CREATE  INDEX [IX_FM_TaskQueue_2] ON [dbo].[FM_TaskQueue]([EventRef]) ON [PRIMARY]
GO

PRINT 'Populating tables...'

SET NOCOUNT ON
PRINT '..FM_EventAction'
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0000', 0, 'Undefined', 'Undefined' )
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0001', 1, 'Start', 'Start')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0002', 2, 'Pause', 'Pause - only applies to Foreman kernel components (not tasks)')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0003', 3, 'Continue', 'Continue - only applies to Foreman kernel components (not tasks)')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0004', 4, 'Stop', 'Stop')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0005', 5, 'Process', 'process a task')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0006', 6, 'QueryRunState', 'returns FmRunState')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0007', 7, 'QueryProcessingState', 'returns FmProcessingState')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0008', 8, 'QueryProcessingOutstanding', 'returns TRUE or FALSE, cumulative')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0009', 9, 'Initialise', 'dependent on Component')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0010', 10, 'SignalEvent', 'wake up a queue processor, if it has a named wait win32-event')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0011', 11, 'SetPriorityFilter', 'set the priority level used to filter items of Event/Task queues')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0012', 12, 'GetPriorityFilter', 'get the priority level used to filter items of Event/Task queues')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0013', 13, 'Shutdown', 'minimal cleanup on service shutdown')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0014', 14, 'Refresh', 'Re-load any cached data.')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0015', 15, 'QueueRecovery', 'During Foreman startup, check the queues for inconsistent entries.')
INSERT INTO FM_EventAction (NtkObjectId, EventActionId, EventActionName, EventActionDesc) VALUES ('0016', 16, 'ArchiveEvent', 'Archive an EventQ entry and its associated TaskQ  entries.')

PRINT '..FM_EventClass'
INSERT INTO FM_EventClass (NtkObjectId, EventClassRef, EventClassDesc, EventGroupRef, EventConcurrencyRef, DefaultEventStateId, DefaultEventPriority, DefaultEventActionId, SuppressOperatorAlert, KeepEventStateHistory, UsesEventSet, ActiveFrom, ActiveTo, ArchiveOption, ComponentName) VALUES ('0001', 'NtkEcForemanKernel', 'Control event for stopping the foreman service if run as an app.', Null, 'Serial', 6, 1, 1, 0, 0, 0, '', '', 2, 'xNetik' )
INSERT INTO FM_EventClass (NtkObjectId, EventClassRef, EventClassDesc, EventGroupRef, EventConcurrencyRef, DefaultEventStateId, DefaultEventPriority, DefaultEventActionId, SuppressOperatorAlert, KeepEventStateHistory, UsesEventSet, ActiveFrom, ActiveTo, ArchiveOption, ComponentName) VALUES ('0002', 'NtkEcProcAll', 'Control event to manipulate all Foreman Kernel Queue processors', Null, 'Serial', 6, 2, 1, 0, 0, 0, '', '', 2, 'xNetik' )
INSERT INTO FM_EventClass (NtkObjectId, EventClassRef, EventClassDesc, EventGroupRef, EventConcurrencyRef, DefaultEventStateId, DefaultEventPriority, DefaultEventActionId, SuppressOperatorAlert, KeepEventStateHistory, UsesEventSet, ActiveFrom, ActiveTo, ArchiveOption, ComponentName) VALUES ('0003', 'NtkEcQpEventAll', 'Control event for all Event Queue processors', Null, 'Serial', 6, 2, 1, 0, 0, 0, '', '', 2, 'xNetik')
INSERT INTO FM_EventClass (NtkObjectId, EventClassRef, EventClassDesc, EventGroupRef, EventConcurrencyRef, DefaultEventStateId, DefaultEventPriority, DefaultEventActionId, SuppressOperatorAlert, KeepEventStateHistory, UsesEventSet, ActiveFrom, ActiveTo, ArchiveOption, ComponentName) VALUES ('0005', 'NtkEcQpEventNotify', 'Control event for the ''Notification'' Event Queue processor', Null, 'Serial', 6, 2, 1, 0, 0, 0, '', '', 2, 'xNetik')
INSERT INTO FM_EventClass (NtkObjectId, EventClassRef, EventClassDesc, EventGroupRef, EventConcurrencyRef, DefaultEventStateId, DefaultEventPriority, DefaultEventActionId, SuppressOperatorAlert, KeepEventStateHistory, UsesEventSet, ActiveFrom, ActiveTo, ArchiveOption, ComponentName) VALUES ('0007', 'NtkEcQpEventProcessed', 'Control event for the ''Processed'' Event Queue processor', Null, 'Serial', 6, 2, 1, 0, 0, 0, '', '', 2, 'xNetik')
INSERT INTO FM_EventClass (NtkObjectId, EventClassRef, EventClassDesc, EventGroupRef, EventConcurrencyRef, DefaultEventStateId, DefaultEventPriority, DefaultEventActionId, SuppressOperatorAlert, KeepEventStateHistory, UsesEventSet, ActiveFrom, ActiveTo, ArchiveOption, ComponentName) VALUES ('0006', 'NtkEcQpEventUnScheduled', 'Control event for the ''Unscheduled'' Event Queue processor', Null, 'Serial', 6, 2, 1, 0, 0, 0, '', '', 2, 'xNetik')
INSERT INTO FM_EventClass (NtkObjectId, EventClassRef, EventClassDesc, EventGroupRef, EventConcurrencyRef, DefaultEventStateId, DefaultEventPriority, DefaultEventActionId, SuppressOperatorAlert, KeepEventStateHistory, UsesEventSet, ActiveFrom, ActiveTo, ArchiveOption, ComponentName) VALUES ('0004', 'NtkEcQpTaskAll', 'Control event for all Task Queue processors', Null, 'Serial', 6, 2, 1, 0, 0, 0, '', '', 2, 'xNetik')
INSERT INTO FM_EventClass (NtkObjectId, EventClassRef, EventClassDesc, EventGroupRef, EventConcurrencyRef, DefaultEventStateId, DefaultEventPriority, DefaultEventActionId, SuppressOperatorAlert, KeepEventStateHistory, UsesEventSet, ActiveFrom, ActiveTo, ArchiveOption, ComponentName) VALUES ('0009', 'NtkEcQpTaskProcessed', 'Control event for the ''Processed'' Task Queue processor', Null, 'Serial', 6, 2, 1, 0, 0, 0, '', '', 2, 'xNetik')
INSERT INTO FM_EventClass (NtkObjectId, EventClassRef, EventClassDesc, EventGroupRef, EventConcurrencyRef, DefaultEventStateId, DefaultEventPriority, DefaultEventActionId, SuppressOperatorAlert, KeepEventStateHistory, UsesEventSet, ActiveFrom, ActiveTo, ArchiveOption, ComponentName) VALUES ('0008', 'NtkEcQpTaskUnScheduled', 'Control event for the ''Unscheduled'' Task Queue processor', Null, 'Serial', 6, 2, 1, 0, 0, 0, '', '', 2, 'xNetik')
INSERT INTO FM_EventClass (NtkObjectId, EventClassRef, EventClassDesc, EventGroupRef, EventConcurrencyRef, DefaultEventStateId, DefaultEventPriority, DefaultEventActionId, SuppressOperatorAlert, KeepEventStateHistory, UsesEventSet, ActiveFrom, ActiveTo, ArchiveOption, ComponentName) VALUES ('0010', 'NtkEcQueueProcTaskProcessedError', 'Control event for the ''Processed in Error'' Task Queue processor', Null, 'Serial', 6, 2, 1, 0, 0, 0, '', '', 2, 'xNetik')
INSERT INTO FM_EventClass (NtkObjectId, EventClassRef, EventClassDesc, EventGroupRef, EventConcurrencyRef, DefaultEventStateId, DefaultEventPriority, DefaultEventActionId, SuppressOperatorAlert, KeepEventStateHistory, UsesEventSet, ActiveFrom, ActiveTo, ArchiveOption, ComponentName) VALUES ('0012', 'NtkEcTaskClass', 'Contained by EcTaskManager', Null, 'Serial', 6, 2, 1, 0, 0, 0, '', '', 2, 'xNetik')
INSERT INTO FM_EventClass (NtkObjectId, EventClassRef, EventClassDesc, EventGroupRef, EventConcurrencyRef, DefaultEventStateId, DefaultEventPriority, DefaultEventActionId, SuppressOperatorAlert, KeepEventStateHistory, UsesEventSet, ActiveFrom, ActiveTo, ArchiveOption, ComponentName) VALUES ('0013', 'NtkEcTaskInstance', 'Contained by EcTaskManager and EcTaskClass', Null, 'Serial', 6, 2, 1, 0, 0, 0, '', '', 2, 'xNetik')
INSERT INTO FM_EventClass (NtkObjectId, EventClassRef, EventClassDesc, EventGroupRef, EventConcurrencyRef, DefaultEventStateId, DefaultEventPriority, DefaultEventActionId, SuppressOperatorAlert, KeepEventStateHistory, UsesEventSet, ActiveFrom, ActiveTo, ArchiveOption, ComponentName) VALUES ('0011', 'NtkEcTaskManager', 'The component that manages task instances', Null, 'Serial', 6, 2, 1, 0, 0, 0, '', '', 2, 'xNetik')
INSERT INTO FM_EventClass (NtkObjectId, EventClassRef, EventClassDesc, EventGroupRef, EventConcurrencyRef, DefaultEventStateId, DefaultEventPriority, DefaultEventActionId, SuppressOperatorAlert, KeepEventStateHistory, UsesEventSet, ActiveFrom, ActiveTo, ArchiveOption, ComponentName) VALUES ('0000', 'Startup', 'All pre-started persistent tasks', Null, 'FirstOnly', 1, 5, 1, 0, 0, 0, '', '', 2, 'xNetik')

PRINT '..FM_EventConcurrency'

INSERT INTO FM_EventConcurrency (NtkObjectId, EventConcurrencyRef, EventConcurrencyDesc) VALUES ('0001', 'Concurrent', 'Events of the same class can be processed concurrently.')
INSERT INTO FM_EventConcurrency (NtkObjectId, EventConcurrencyRef, EventConcurrencyDesc) VALUES ('0004', 'FirstOnly', 'For an event not completed, subsequent events of the same class are discarded.')
INSERT INTO FM_EventConcurrency (NtkObjectId, EventConcurrencyRef, EventConcurrencyDesc) VALUES ('0005', 'LastOnly', 'Not yet implemented.')
INSERT INTO FM_EventConcurrency (NtkObjectId, EventConcurrencyRef, EventConcurrencyDesc) VALUES ('0002', 'Serial', 'Events of the same class are processed sequentially. Continue Pending items even if previous events of the same class completed in error')
INSERT INTO FM_EventConcurrency (NtkObjectId, EventConcurrencyRef, EventConcurrencyDesc) VALUES ('0003', 'SerialDependent', 'Events of the same class are processed sequentially. Only continue Pending items if all previous events of the same class completed OK')

PRINT '..FM_EventState'

INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0001', 0, 'Undefined', 'None of the below. The Foreman won''t recognise these as far as workflow goes.', 1, 0, 1, 0, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0002', 1, 'Notify', 'Normally goes onto the EventQueue in this state if found on EventClass table.', 2, 1, 0, 1, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0003', 2, 'NotifyPaused', 'Manually paused, something must un-pause this for anything else to happen.', 3, 1, 0, 1, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0004', 3, 'NotifyPendingConcurrency', 'Waiting for previous events due to the ''concurrency'' defined for the event class.', 4, 1, 0, 1, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0005', 4, 'NotifyPendingAES', 'Waiting for previous events in an Active Event Set', 4, 1, 0, 1, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0006', 5, 'UnIdentified', 'Goes onto the EventQueue in this state if NOT found on EventClass table.', 5, 0, 1, 1, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0007', 6, 'Discarded', 'Can be used to discard an event (i.e. no further processing will be performed).', 6, 0, 0, 1, 'xNetik', Null, Null, 1)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0008', 7, 'ControlOnly', 'Used for control events that do not require task mappings.', 7, 0, 0, 1, 'xNetik', Null, Null, 1)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0009', 8, 'UnScheduled', 'OK and ready for scheduling for Workflow.', 8, 1, 0, 0, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0010', 9, 'BeingScheduled', 'Currently being scheduled by Workflow manager (I.e. creating TaskQueue entries)', 9, 1, 0, 0, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0011', 10, 'ScheduledInError', 'Severe error during scheduling.', 10, 0, 1, 0, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0012', 11, 'ScheduledOk', 'Scheduled OK and tasks are being processed.', 11, 1, 0, 0, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0013', 12, 'ScheduledNull', 'No mappings between EventClass and TaskClass found!', 12, 0, 0, 0, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0014', 13, 'ProcessedOk', 'Related task(s) completed OK.', 13, 1, 0, 0, 'xNetik', Null, Null, 1)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0015', 14, 'ProcessedWithErrorContinue', 'Related task(s) completed with errors but continued.', 14, 1, 0, 0, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0016', 15, 'ProcessedWithErrorStop', 'Related task(s) encountered errors and stopped. Workflow stopped for this event.', 15, 0, 1, 0, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0017', 16, 'ProcessedWithSevereError', 'Related task(s) encountered severe (e.g. framework) errors. Workflow stopped for this event.', 16, 0, 1, 0, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0018', 17, 'CompletedOk', 'Finished all processing successfully.', 17, 0, 0, 0, 'xNetik', Null, Null, 1)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0019', 18, 'CompletedWithErrorContinue', 'Finished all processing with some ''continue'' errors.', 18, 0, 0, 0, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0020', 19, 'CompletedWithErrorStop', 'Encountered an error during processing. Workflow stopped for this event.', 19, 0, 1, 0, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0021', 20, 'CompletedWithSevereError', 'Encountered a severe error during processing. Workflow stopped for this event.', 20, 0, 1, 0, 'xNetik', Null, Null, 0)
INSERT INTO FM_EventState (NtkObjectId, EventStateId, EventStateName, EventStateDesc, EventStateOrder, FurtherProcessing, OperatorAlert, ValidInitialState, ComponentName, ProductVersion, NRSInfo, IsArchive) VALUES ('0022', 21, 'CompletedWithInterruption', 'Inconsistent state spotted durung foreman startup - investigate the event and all child tasks.', 21, 0, 1, 0, 'xNetik', Null, Null, 0)

PRINT '..FM_TaskClass'

INSERT INTO FM_TaskClass (NtkObjectId, TaskClassRef, TaskClassDesc, TaskTypeRef, TaskProgId, PersistentTask, ProcessSingleTaskOnly, ComponentName, ProductVersion, NRSInfo, MaxInstanceCount, DefaultAckTimeout, MaxInstanceUsage) VALUES ('0001', 'FileListener', 'Generic file listener', 'Complex', 'FmComFileListener.FmComFileListener.1', 1, 1, 'xNetik', Null, Null, Null, 20000, Null)
INSERT INTO FM_TaskClass (NtkObjectId, TaskClassRef, TaskClassDesc, TaskTypeRef, TaskProgId, PersistentTask, ProcessSingleTaskOnly, ComponentName, ProductVersion, NRSInfo, MaxInstanceCount, DefaultAckTimeout, MaxInstanceUsage) VALUES ('99501', 'FileToFile', 'Splits an input File to many target output Files', 'Complex', 'xNetik.FileToFile.1', 1, 0, 'xNetik', Null, Null, Null, 4000, Null)
INSERT INTO FM_TaskClass (NtkObjectId, TaskClassRef, TaskClassDesc, TaskTypeRef, TaskProgId, PersistentTask, ProcessSingleTaskOnly, ComponentName, ProductVersion, NRSInfo, MaxInstanceCount, DefaultAckTimeout, MaxInstanceUsage) VALUES ('98501', 'FileToMsmq', 'Splits an input File to many target output Message Queues', 'Complex', 'xNetik.FileToMsmq.1', 1, 0, 'xNetik', Null, Null, Null, 4000, Null)
INSERT INTO FM_TaskClass (NtkObjectId, TaskClassRef, TaskClassDesc, TaskTypeRef, TaskProgId, PersistentTask, ProcessSingleTaskOnly, ComponentName, ProductVersion, NRSInfo, MaxInstanceCount, DefaultAckTimeout, MaxInstanceUsage) VALUES ('0002', 'GtFile', 'Global Translator - file processor', 'Standard', 'xNetik.GtTask.1', 1, 0, 'xNetik', Null, Null, Null, 60000, 50)
INSERT INTO FM_TaskClass (NtkObjectId, TaskClassRef, TaskClassDesc, TaskTypeRef, TaskProgId, PersistentTask, ProcessSingleTaskOnly, ComponentName, ProductVersion, NRSInfo, MaxInstanceCount, DefaultAckTimeout, MaxInstanceUsage) VALUES ('0006', 'GtFtp', 'Global Translator - ftp processor', 'Standard', 'xNetik.GtTask.1', 1, 0, 'xNetik', Null, Null, Null, 60000, 50)
INSERT INTO FM_TaskClass (NtkObjectId, TaskClassRef, TaskClassDesc, TaskTypeRef, TaskProgId, PersistentTask, ProcessSingleTaskOnly, ComponentName, ProductVersion, NRSInfo, MaxInstanceCount, DefaultAckTimeout, MaxInstanceUsage) VALUES ('96050', 'GtMsmq', 'Global Translator - MSMQ processor', 'Standard', 'xNetik.GtTask.1', 1, 0, 'xNetik', Null, Null, Null, 60000, 50)
INSERT INTO FM_TaskClass (NtkObjectId, TaskClassRef, TaskClassDesc, TaskTypeRef, TaskProgId, PersistentTask, ProcessSingleTaskOnly, ComponentName, ProductVersion, NRSInfo, MaxInstanceCount, DefaultAckTimeout, MaxInstanceUsage) VALUES ('0003', 'GtOdbc', 'Global Translator - odbc processor', 'Standard', 'xNetik.GtTask.1', 1, 0, 'xNetik', Null, Null, Null, 60000, 50)
INSERT INTO FM_TaskClass (NtkObjectId, TaskClassRef, TaskClassDesc, TaskTypeRef, TaskProgId, PersistentTask, ProcessSingleTaskOnly, ComponentName, ProductVersion, NRSInfo, MaxInstanceCount, DefaultAckTimeout, MaxInstanceUsage) VALUES ('0004', 'GtParam', 'Global Translator - parameter (via Foreman) processor', 'Standard', 'xNetik.GtTask.1', 1, 0, 'xNetik', Null, Null, Null, 60000, 50)
INSERT INTO FM_TaskClass (NtkObjectId, TaskClassRef, TaskClassDesc, TaskTypeRef, TaskProgId, PersistentTask, ProcessSingleTaskOnly, ComponentName, ProductVersion, NRSInfo, MaxInstanceCount, DefaultAckTimeout, MaxInstanceUsage) VALUES ('0005', 'GtSkt', 'Global Translator - socket processor', 'Standard', 'xNetik.GtTask.1', 1, 0, 'xNetik', Null, Null, Null, 60000, 50)
INSERT INTO FM_TaskClass (NtkObjectId, TaskClassRef, TaskClassDesc, TaskTypeRef, TaskProgId, PersistentTask, ProcessSingleTaskOnly, ComponentName, ProductVersion, NRSInfo, MaxInstanceCount, DefaultAckTimeout, MaxInstanceUsage) VALUES ('46A9BEA4-66A4-412a-AC8C-EA1A666E110B', 'GtStream', 'Global Translator - stream processor', 'Standard', 'xNetik.xNGtStream.1', 1, 0, 'xNetik', Null, Null, Null, 20000, Null)
INSERT INTO FM_TaskClass (NtkObjectId,TaskClassRef,TaskClassDesc,TaskTypeRef,TaskProgId,PersistentTask,ProcessSingleTaskOnly,DefaultAckTimeout,ComponentName) VALUES ('484F34C5-7864-4428-A490-E2205A1A7864','FileTransfer','Standard FTP file transfer task','Standard','xNetik.XnFileTransferTask.1',1,0,60000,'xNetik')
INSERT INTO FM_TaskClass (NtkObjectId, TaskClassRef, TaskClassDesc, TaskTypeRef, TaskProgId, PersistentTask, ProcessSingleTaskOnly, ComponentName, DefaultAckTimeout) VALUES ( '288AC793-85B8-4884-8BD7-6D47A90742E9', 'MultiFileListener', 'File Listener - multiple', 'Standard', 'xNetik.FileListener.1', '1', '1', 'xNetik', '20000' )
INSERT INTO FM_TaskClass (NtkObjectId, TaskClassRef, TaskClassDesc, TaskTypeRef, TaskProgId, PersistentTask, ProcessSingleTaskOnly, ComponentName, DefaultAckTimeout) VALUES ('6451E974-9EEC-4667-BA23-FC367461B8D4','MQSeriesToFile','MQSeriesToFile','Standard','xNetik.MQSeriesToFile.1','1','0','xNetik','20000')

PRINT '..FM_TaskClassParam'

INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('0002', 'FileListener', 'FileMask', 'The file mask', 2 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('0003', 'FileListener', 'FileMaskCaseSensitive', 'Whether the file mask is case sensitive or not', 3 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('0006', 'FileListener', 'FileOpenRetryCountMax', 'How many times it will try and open the file if it''s locked', 6 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('0007', 'FileListener', 'FileOpenRetryWaitTime', 'How long it will wait (millisecs) between each retry', 7 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('0008', 'FileListener', 'PollingInterval', 'Optional polling interval (millisecs), used when win32 file change notifications are not supported by a remote file system', 8 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('0001', 'FileListener', 'ScanDir', 'Where it looks', 1 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('0005', 'FileListener', 'TriggerEventClassRef', 'The event class that gets triggered when a file is found', 5 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('0004', 'FileListener', 'WorkDir', 'Where the found file gets placed prior to being worked on', 4 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('99508', 'FileToFile', 'CheckContinuePeriod', ' ', 8 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('99502', 'FileToFile', 'DeviceName', 'The file (full path) to load', 2 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('99513', 'FileToFile', 'FileSequenceKey', 'Optional - target files have a seq number appended if this is specified', 13)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('99504', 'FileToFile', 'InputRecordTerm', 'Optional. Specifies dynamic length record delimiter (In).', 4)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('99501', 'FileToFile', 'LoadName', 'Informational', 1 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('99506', 'FileToFile', 'MaxRecordLen', 'Optional. Specifies dynamic record maximum length.', 6 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('99514', 'FileToFile', 'OriginalFileName', 'The original file', 14 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('99507', 'FileToFile', 'OutputCount', 'How many output files', 7 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('99505', 'FileToFile', 'OutputRecordTerm', 'Optional. Specifies dynamic length record delimiter (Out).', 5 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('99503', 'FileToFile', 'RecordLen', 'Optional. Specifies fixed length record length.', 3 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('99509', 'FileToFile', 'SuppressNotify', ' ', 9 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('99510', 'FileToFile', 'SuppressNotifyAtEnd', ' ', 10 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('99512', 'FileToFile', 'TargetDir', 'The final output directory', 12 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder) VALUES ('99511', 'FileToFile', 'TempDir', 'Optional - file created here first if specified', 11 )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue) VALUES ('99526', 'FileToFile', 'UnicodeMode', 'Data format [M]Multibyte/ASCII, [U]Unicode, [B]Binary', 26, 'M' )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('99516', 'FileToFile', 'Weight1', ' ', 16)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('99525', 'FileToFile', 'Weight10', ' ', 25)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('99517', 'FileToFile', 'Weight2', ' ', 17)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('99518', 'FileToFile', 'Weight3', ' ', 18)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('99519', 'FileToFile', 'Weight4', ' ', 19)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('99520', 'FileToFile', 'Weight5', ' ', 20)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('99521', 'FileToFile', 'Weight6', ' ', 21)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('99522', 'FileToFile', 'Weight7', ' ', 22)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('99523', 'FileToFile', 'Weight8', ' ', 23)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('99524', 'FileToFile', 'Weight9', ' ', 24)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('99515', 'FileToFile', 'WeightCycle', ' ', 15)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('98508', 'FileToMsmq', 'CheckContinuePeriod', ' ', 8)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('98502', 'FileToMsmq', 'DeviceName', 'The file (full path) to load', 2)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('98512', 'FileToMsmq', 'EofRecord', 'The record to be written to the Q to signify end of data', 12)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder ) VALUES ('98504', 'FileToMsmq', 'InputRecordTerm', 'Optional. Specifies dynamic length record delimiter (In).', 4)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98501', 'FileToMsmq', 'LoadName', 'Informational', 1, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98506', 'FileToMsmq', 'MaxRecordLen', 'Optional. Specifies dynamic record maximum length.', 6, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98514', 'FileToMsmq', 'OriginalFileName', 'The original file', 14, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98507', 'FileToMsmq', 'OutputCount', 'How many output files', 7, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98505', 'FileToMsmq', 'OutputRecordTerm', 'Optional. Specifies dynamic length record delimiter (Out).', 5, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98511', 'FileToMsmq', 'QueuePrefix', 'Msmq name prefix', 11, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98503', 'FileToMsmq', 'RecordLen', 'Optional. Specifies fixed length record length.', 3, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98526', 'FileToMsmq', 'SplitterProgId', ' ', 26, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98509', 'FileToMsmq', 'SuppressNotify', ' ', 9, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98510', 'FileToMsmq', 'SuppressNotifyAtEnd', ' ', 10, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98527', 'FileToMsmq', 'UnicodeMode', 'Data format [M]Multibyte/ASCII, [U]Unicode, [B]Binary', 27, 'M', 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98516', 'FileToMsmq', 'Weight1', ' ', 16, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98525', 'FileToMsmq', 'Weight10', ' ', 25, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98517', 'FileToMsmq', 'Weight2', ' ', 17, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98518', 'FileToMsmq', 'Weight3', ' ', 18, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98519', 'FileToMsmq', 'Weight4', ' ', 19, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98520', 'FileToMsmq', 'Weight5', ' ', 20, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98521', 'FileToMsmq', 'Weight6', ' ', 21, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98522', 'FileToMsmq', 'Weight7', ' ', 22, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98523', 'FileToMsmq', 'Weight8', ' ', 23, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98524', 'FileToMsmq', 'Weight9', ' ', 24, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('98515', 'FileToMsmq', 'WeightCycle', ' ', 15, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0020', 'GtFile', 'BulkLoad', 'Volume Translator', 10, Null, Null, Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0015', 'GtFile', 'DataConversion', 'The data conversion', 5, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0017', 'GtFile', 'DeviceName', 'The device name (e.g. file)', 7, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0012', 'GtFile', 'JobName', 'The job name', 2, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0011', 'GtFile', 'JobTarget', 'The job target', 1, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0018', 'GtFile', 'OriginalFileName', 'The full path of the original file captured in the ScanDir', 8, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0014', 'GtFile', 'Stream', 'The stream', 4, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0013', 'GtFile', 'System', 'The system', 3, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0016', 'GtFile', 'UserName', 'The username used to logon', 6, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0019', 'GtFile', 'WorkDir', 'The full path of the target work directory. Used for file Replay.', 9, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0055', 'GtFtp', 'DataConversion', 'The data conversion', 5, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0057', 'GtFtp', 'DeviceName', 'The device name', 7, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0052', 'GtFtp', 'JobName', 'The job name', 2, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0051', 'GtFtp', 'JobTarget', 'The job target', 1, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0054', 'GtFtp', 'Stream', 'The stream', 4, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0053', 'GtFtp', 'System', 'The system', 3, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0056', 'GtFtp', 'UserName', 'The username used to logon', 6, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('96055', 'GtMsmq', 'DataConversion', 'DataConversion', 5, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('96052', 'GtMsmq', 'JobName', 'JobName', 2, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('96051', 'GtMsmq', 'JobTarget', 'JobTarget', 1, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('96056', 'GtMsmq', 'MSMQ.QueueName', 'The queue name', 6, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('96054', 'GtMsmq', 'Stream', 'Stream', 4, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('96053', 'GtMsmq', 'System', 'System', 3, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0025', 'GtOdbc', 'DataConversion', 'The data conversion', 5, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0022', 'GtOdbc', 'JobName', 'The job name', 2, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0021', 'GtOdbc', 'JobTarget', 'The job target', 1, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0024', 'GtOdbc', 'Stream', 'The stream', 4, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0023', 'GtOdbc', 'System', 'The system', 3, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0026', 'GtOdbc', 'UserName', 'The username used to logon', 6, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0035', 'GtParam', 'DataConversion', 'The data conversion', 5, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0037', 'GtParam', 'InputData', 'The source data.', 7, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0032', 'GtParam', 'JobName', 'The job name', 2, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0031', 'GtParam', 'JobTarget', 'The job target', 1, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0034', 'GtParam', 'Stream', 'The stream', 4, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0033', 'GtParam', 'System', 'The system', 3, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0036', 'GtParam', 'UserName', 'The username used to logon', 6, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0044', 'GtSkt', 'DataConversion', 'The data conversion', 5, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0042', 'GtSkt', 'JobName', 'The job name', 2, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0041', 'GtSkt', 'JobTarget', 'The job target', 1, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0043', 'GtSkt', 'Stream', 'The stream', 4, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0042', 'GtSkt', 'System', 'The system', 3, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('0045', 'GtSkt', 'UserName', 'The username used to logon', 6, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('BBFC54DF-D229-7E4F-9845-8674B2F2B199', 'GtStream', 'ConvertInstructionPre', 'The convert instruction location.', 7, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('6E4A6C42-E06F-A740-93B7-83CBDF47EDAA', 'GtStream', 'DataConversion', 'The xNetik task name.', 1, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('217BC2D5-E53A-AB46-A243-B72BD9A27691', 'GtStream', 'DataSchema', 'The data schema location.', 2, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('AE064EC0-6973-434E-8D45-106AE9449B81', 'GtStream', 'DeviceName', 'The source data location.', 4, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('9EB8D60B-3939-ED47-A947-2929B873ACB5', 'GtStream', 'ParseInstruction', 'The parse instruction location.', 3, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('D19A020F-495C-5347-9BA4-91DB585DD4F0', 'GtStream', 'Stream', 'The source stream name.', 5, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('BBFC54DF-D229-7E4F-9845-8674B2F2B199', 'GtStream', 'System', 'The source system name.', 6, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue, ComponentName, ProductVersion, NRSInfo) VALUES ('BBFC54DF-D229-7E4F-9845-8674B2F2B199', 'GtStream', 'ValidateInstruction', 'The validate instruction location.', 8, Null, 'xNetik', Null, Null)
INSERT INTO FM_TaskClassParam VALUES ('26EEC87B-A643-458B-A351-26DCA8DC20E8','GtStream','ConvertInstructionPost','The post-validate convert instruction location.', 10, NULL,'xNetik', NULL, NULL)
INSERT INTO FM_TaskClassParam VALUES ('4FFA5C8A-2240-4ac9-B4BE-AED7D67B9C72','FileTransfer','ScriptName','FTP command script file',1,NULL,'xNetik',NULL,NULL)
INSERT INTO FM_TaskClassParam VALUES ('4FD1F5BB-203C-42f6-B507-56BAF7DEC770','FileTransfer','DeviceName','File to be transferred',2,NULL,'xNetik',NULL,NULL)
INSERT INTO FM_TaskClassParam VALUES ('EC60D562-4C35-4bcc-9E90-6B99BCD142C7','FileTransfer','TargetFile','Destination file to be created',3,NULL,'xNetik',NULL,NULL)
INSERT INTO FM_TaskClassParam VALUES ('D7FC44C2-5A06-451d-907B-CA46E76DCA99','FileTransfer','WriteOption','',4,'Append','xNetik',NULL,NULL)
INSERT INTO FM_TaskClassParam VALUES ('C67A793E-C44B-4914-9482-A9F9715D721D','FileTransfer','ConnectTimeout','',5,'5000','xNetik',NULL,NULL)
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, ComponentName ) VALUES ( 'A30E8BB8-84FE-4cd0-9CA0-D7B71947CA2D', 'MultiFileListener', '_XnListenXml', 'The Multi File Listener XML configuration file', '1', 'xNetik' )
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue) VALUES ('ACB63604-93F4-4E68-96FB-C895D6FB2E99','MQSeriesToFile','Is MqSeries client','Is MqSeries client','1','No')
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue) VALUES ('2401857B-6480-47E7-9D7B-26A5953382DC','MQSeriesToFile','Queue Manager name','Queue Manager name','2','')
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue) VALUES ('11FF3C8A-74AA-4F3C-B3E4-96BAE9F6F608','MQSeriesToFile','Queue name','Queue name','3','')
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue) VALUES ('B59F1955-2202-40B0-A1D2-C47F1366106C','MQSeriesToFile','Timeout(ms)','Timeout(ms)','4','-1')
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue) VALUES ('B59F1955-2202-40B0-A1D2-C47F1366106C','MQSeriesToFile','Rollback if stopped','Rollback if stopped','4','No')
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue) VALUES ('BA4F549C-C4BF-495A-95D0-67F16A739EBE','MQSeriesToFile','File pathname','File pathname','5','e.g. : C:\Files\MyFile<MySequenceName>.dat')
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue) VALUES ('9B6F5285-1630-4404-BA7A-5F088D923C5A','MQSeriesToFile','Lock file','Lock file','6','Yes')
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue) VALUES ('29E68A76-B89B-4EA2-ADE3-59F74DEABE57','MQSeriesToFile','Temp folder','Temp folder','7','')
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue) VALUES ('50BC0FE9-BF44-4EFE-BEBB-13E1CE3C1806','MQSeriesToFile','Max batch size','Max batch size','8','1')
INSERT INTO FM_TaskClassParam (NtkObjectId, TaskClassRef, TaskClassParamRef, TaskClassParamDesc, DefaultParamOrder, DefaultValue) VALUES ('9589A9D4-10B8-40E0-8523-DE36B881F4F9','MQSeriesToFile','Append to file','Append to file','9','No')



PRINT '..FM_TaskState'

INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0001', 0, 'Undefined', 'Not defined.', 0, 1, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0002', 1, 'Notify', 'Currently missed out (i.e. not used).', 1, 1, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0003', 2, 'NotifyPendingATS', 'Waiting for previous tasks in an Active Task Set', 2, 0, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0004', 3, 'UnIdentified', 'Goes onto the TaskQueue in this state if NOT found on TaskClass table.', 3, 1, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0005', 4, 'Discarded', 'Not currently used. Can be set manually to this to discard a task.', 4, 0, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0006', 5, 'UnScheduled', 'OK and ready for Task scheduling. Goes onto the TaskQueue in this state if found on TaskClass table.', 5, 0, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0007', 6, 'BeingScheduled', 'Currently being scheduled by Task manager', 6, 0, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0008', 7, 'ScheduledInError', 'Severe error during Task scheduling.', 7, 1, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0009', 8, 'ScheduledOk', 'Task scheduled OK - up and running.', 8, 0, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0010', 9, 'ScheduledNull', 'Not found on FM_TaskClass table', 9, 0, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0011', 10, 'Processing', 'Task currently processing.', 10, 0, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0012', 11, 'ProcessedOk', 'Task completed OK.', 11, 0, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0013', 12, 'ProcessedWithErrorContinue', 'Task completed with errors but continued.', 12, 0, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0014', 13, 'ProcessedWithInterruption', 'Task was processing when it was interrupted and forced to stop. Workflow for the event stops here.', 13, 0, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0015', 14, 'ProcessedWithErrorStop', 'Task encountered errors and stopped. Workflow for the event stops here.', 14, 1, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0016', 15, 'ProcessedWithSevereError', 'Task encountered severe (e.g. framework) errors and stopped. Workflow for the event stops here.', 15, 1, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0017', 16, 'CompletedOk', 'Finished all processing successfully. Now ready for archiving (if extra rules permit).', 16, 0, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0018', 17, 'CompletedWithErrorContinue', 'Finished all processing with some ''continue'' errors. Now ready for archiving (if extra rules permit).', 17, 0, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0019', 18, 'CompletedWithInterruption', 'Task was processing when it was interrupted and forced to stop. Workflow for the event stops here.', 18, 0, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0020', 19, 'CompletedWithErrorStop', 'Encountered a ''stop'' error during processing. Workflow for the event stops here.', 19, 1, 'xNetik', Null, Null)
INSERT INTO FM_TaskState (NtkObjectId, TaskStateId, TaskStateName, TaskStateDesc, TaskStateOrder, OperatorAlert, ComponentName, ProductVersion, NRSInfo) VALUES ('0021', 20, 'CompletedWithSevereError', 'Encountered a severe error during processing. Workflow for the event stops here.', 20, 1, 'xNetik', Null, Null)

PRINT '..FM_TaskType'
INSERT INTO FM_TaskType (NtkObjectId, TaskTypeRef, TaskTypeDesc ) VALUES ('0003', 'Complex', 'Implement IFmComControl for an asychronous task supporting notifications. Requires secondary thread for asynchronicity.' )
INSERT INTO FM_TaskType (NtkObjectId, TaskTypeRef, TaskTypeDesc ) VALUES ('0002', 'Medium', 'Implement IFmComTaskMedium for a synchronous task supporting notification callbacks. Not yet supported.')
INSERT INTO FM_TaskType (NtkObjectId, TaskTypeRef, TaskTypeDesc ) VALUES ('0001', 'Simple', 'Implement IFmComTaskSimple for a sychronous task (simple Process() method)')

PRINT 'Netik Interchange 2.3 Global Translator day zero'

PRINT 'Dropping existing tables...'

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_BusinessService]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_BusinessService]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_BusinessServiceInterface]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_BusinessServiceInterface]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_BusinessServiceShape]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_BusinessServiceShape]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_Component]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_Component]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_ContextField]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_ContextField]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_DataConversion]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_DataConversion]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_Enumeration]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_Enumeration]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_EnumSet]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_EnumSet]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_Extension]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_Extension]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_ExternalSystem]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_ExternalSystem]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_FieldFormat]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_FieldFormat]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_FieldGroup]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_FieldGroup]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_FieldGroupInStream]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_FieldGroupInStream]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_FieldTranslationSet]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_FieldTranslationSet]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_Hook]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_Hook]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_LiteralToken]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_LiteralToken]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_Lookup]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_Lookup]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_MessageField]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_MessageField]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_Nvp]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_Nvp]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_ParseFiniteState]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_ParseFiniteState]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_ParseMethod]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_ParseMethod]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_PropertyTest]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_PropertyTest]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_Stream]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_Stream]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_TargetCase]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_TargetCase]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_TargetCondition]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_TargetCondition]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_TargetDecision]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_TargetDecision]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_TargetResult]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_TargetResult]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_TranslationCase]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_TranslationCase]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_TranslationCondition]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_TranslationCondition]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_TranslationDecision]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_TranslationDecision]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_TranslationResult]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_TranslationResult]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[GT_Workflow]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GT_Workflow]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[UA_Adapter]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[UA_Adapter]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[UA_FileDetail]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[UA_FileDetail]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[UA_FtpDetail]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[UA_FtpDetail]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[UA_Location]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[UA_Location]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[UA_MSMQDetail]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[UA_MSMQDetail]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[UA_OdbcDetail]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[UA_OdbcDetail]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[UA_Property]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[UA_Property]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[UA_PropertySet]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[UA_PropertySet]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[UA_SktDetail]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[UA_SktDetail]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[UA_VolLoadDetail]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[UA_VolLoadDetail]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[XML_NodeDef]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[XML_NodeDef]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[XML_NodeState]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[XML_NodeState]

PRINT 'Deleting user defined types..'
SET NOCOUNT ON
if exists (select * from systypes where name = 'T_NtkProgId')
EXEC sp_droptype 'T_NtkProgId'
GO

PRINT 'Creating user defined types...'

setuser 'dbo'
GO

PRINT '..T_NtkProgId'

if not exists (select * from systypes where name = 'T_NtkProgId')
EXEC sp_addtype 'T_NtkProgId', 'varchar (80)', 'null'
GO

PRINT 'Creating tables...'

PRINT '..GT_BusinessService'

CREATE TABLE [dbo].[GT_BusinessService] (
	[BusServName] [varchar] (64) PRIMARY KEY CLUSTERED,
	[Description] [varchar] (255) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[ComName] [varchar] (64) NULL ,
	[ComVersion] [int] NULL ,
	[ComOptions] [int] NULL 
) ON [PRIMARY]
GO

PRINT '..GT_BusinessServiceInterface'

CREATE TABLE [dbo].[GT_BusinessServiceInterface] (
	[BusServName] [varchar] (64) NOT NULL ,
	[FldGrpName] [varchar] (64) NOT NULL ,
	[FldName] [varchar] (64) NOT NULL ,
	[Description] [varchar] (255) NULL ,
	[SortSeq] [int] NULL ,
	[FldType] [varchar] (16) NOT NULL ,
	[KeyNum] [int] NULL ,
	[KeySortSeq] [int] NULL ,
	[FldLen] [int] NULL ,
	[FldScale] [int] NULL ,
	[IsNullIfBlank] [tinyint] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL,
	CONSTRAINT [PK_GT_BusinessServiceInterface] PRIMARY KEY  CLUSTERED 
	(
		[BusServName],
		[FldGrpName],
		[FldName]
	)
) ON [PRIMARY]
GO

PRINT '..GT_BusinessServiceInterface'

CREATE TABLE [dbo].[GT_BusinessServiceShape] (
	[BusServName] [varchar] (64) NOT NULL ,
	[FldGrpName] [varchar] (64) NOT NULL ,
	[Description] [varchar] (255) NULL ,
	[LevelNum] [int] NOT NULL ,
	[SortSeq] [int] NULL ,
	[FldGrpNameParent] [varchar] (64) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	CONSTRAINT [PK_GT_BusinessServiceShape] PRIMARY KEY  CLUSTERED 
	(
		[BusServName],
		[FldGrpName]
	)
) ON [PRIMARY]
GO

PRINT '..GT_Component'

CREATE TABLE [dbo].[GT_Component] (
	[ComponentName] [varchar] (32) NOT NULL ,
	[ProjectName] [varchar] (32) NULL ,
	[ReservationDateTime] [datetime] NULL ,
	CONSTRAINT [PK_GT_Component] PRIMARY KEY  CLUSTERED 
	(
		[ComponentName]
	)
) ON [PRIMARY]
GO

PRINT '..GT_ContextField'

CREATE TABLE [dbo].[GT_ContextField] (
	[Type] [varchar] (16) NOT NULL ,
	[Name] [varchar] (64) NOT NULL ,
	[SortSeq] [int] NOT NULL ,
	[Description] [varchar] (64) NULL ,
	[IsConstant] [tinyint] NOT NULL ,
	[FieldName] [varchar] (32) NOT NULL ,
	[FieldType] [varchar] (16) NOT NULL ,
	[Value] [varchar] (64) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_ContextField] PRIMARY KEY  CLUSTERED 
	(
		[Type],
		[Name],
		[SortSeq]
	)
) ON [PRIMARY]
GO


PRINT '..GT_DataConversion'

CREATE TABLE [dbo].[GT_DataConversion] (
	[DataConvName] [varchar] (64) NOT NULL ,
	[Description] [varchar] (255) NULL ,
	[JobType] [varchar] (16) NULL ,
	[IsInputConstantDef] [tinyint] NOT NULL ,
	[TxnCycleGran] [varchar] (8) NOT NULL ,
	[TxnCyclePeriod] [numeric](18, 0) NOT NULL ,
	[IsBatchAtomicDef] [tinyint] NOT NULL ,
	[IsBadFileUsedDef] [tinyint] NOT NULL ,
	[ErrorCountMaxDef] [numeric](18, 0) NULL ,
	[IsInfoLogDef] [tinyint] NOT NULL ,
	[IsWarnLogDef] [tinyint] NOT NULL ,
	[IsErrorLogDef] [tinyint] NOT NULL ,
	[IsSuccessAuditDef] [tinyint] NOT NULL ,
	[IsFailAuditDef] [tinyint] NOT NULL ,
	[IsInfoRetDef] [tinyint] NOT NULL ,
	[IsWarnRetDef] [tinyint] NOT NULL ,
	[IsErrorRetDef] [tinyint] NOT NULL ,
	[IsSuccessRetDef] [tinyint] NOT NULL ,
	[IsFailRetDef] [tinyint] NOT NULL ,
	[IsInfoAlertDef] [tinyint] NOT NULL ,
	[IsWarnAlertDef] [tinyint] NOT NULL ,
	[IsErrorAlertDef] [tinyint] NOT NULL ,
	[IsSuccessAlertDef] [tinyint] NOT NULL ,
	[IsFailAlertDef] [tinyint] NOT NULL ,
	[DCMServReqDef] [varchar] (16) NULL ,
	[DCMCardinalityDef] [varchar] (16) NULL ,
	[DCMQualTypeDef] [varchar] (16) NULL ,
	[DCMQualValDef] [varchar] (16) NULL ,
	[DCMTxnModeDef] [varchar] (16) NULL ,
	[DCMTxnTypeDef] [varchar] (16) NULL ,
	[DCMResModeDef] [varchar] (16) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_DataConversion] PRIMARY KEY  CLUSTERED 
	(
		[DataConvName]
	)
) ON [PRIMARY]
GO

PRINT '..GT_Enumeration'

CREATE TABLE [dbo].[GT_Enumeration] (
	[EnumSetId] [char] (36) NOT NULL ,
	[EnumId] [char] (36) NOT NULL ,
	[Value] [varchar] (50) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT '..GT_EnumSet'

CREATE TABLE [dbo].[GT_EnumSet] (
	[EnumSetId] [char] (36) NOT NULL ,
	[EnumSetName] [varchar] (255) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT '..GT_Extension'

CREATE TABLE [dbo].[GT_Extension] (
	[ExtensionId] [T_NtkStringId] NOT NULL ,
	[StateId] [varchar] (36) NOT NULL ,
	[OwnerType] [int] NOT NULL ,
	[CallType] [int] NOT NULL ,
	[ProgId] [T_NtkProgId] NOT NULL 
) ON [PRIMARY]
GO

PRINT '..GT_ExternalSystem'

CREATE TABLE [dbo].[GT_ExternalSystem] (
	[ExtSysName] [varchar] (64) NOT NULL ,
	[Description] [varchar] (255) NULL ,
	[CharacterSetDef] [varchar] (16) NULL ,
	[TmnFormatDef] [varchar] (16) NULL ,
	[VarLenSpecifierLenDef] [int] NULL ,
	[EndOfFileDef] [varchar] (16) NULL ,
	[EndOfLineDef] [varchar] (16) NULL ,
	[CsvFldSepDef] [varchar] (16) NULL ,
	[CsvEleDelimDef] [varchar] (16) NULL ,
	[CsvGuardCharDef] [varchar] (1) NULL ,
	[CsvTrimWhiteSpaceDef] [tinyint] NULL ,
	[TagFldSepDef] [varchar] (16) NULL ,
	[TagEleDelimDef] [varchar] (16) NULL ,
	[TagGuardCharDef] [varchar] (1) NULL ,
	[TagDelimTypeDef] [varchar] (16) NULL ,
	[TagBotCharDef] [varchar] (16) NULL ,
	[TagEotCharDef] [varchar] (16) NULL ,
	[TagDelimLenDef] [int] NULL ,
	[TagTrimWhiteSpaceDef] [tinyint] NULL ,
	[AreTagsOrderedDef] [tinyint] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_ExternalSystem] PRIMARY KEY  CLUSTERED 
	(
		[ExtSysName]
	)
) ON [PRIMARY]
GO

PRINT '..GT_FieldFormat'

CREATE TABLE [dbo].[GT_FieldFormat] (
	[FldFmtName] [varchar] (32) NOT NULL ,
	[Description] [varchar] (255) NULL ,
	[FmtCategory] [varchar] (32) NULL ,
	[FmtMask] [varchar] (32) NOT NULL ,
	[CustomFmtName] [varchar] (32) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_FieldFormat] PRIMARY KEY  CLUSTERED 
	(
		[FldFmtName]
	)
) ON [PRIMARY]
GO

PRINT '..GT_FieldGroup'

CREATE TABLE [dbo].[GT_FieldGroup] (
	[FldGrpName] [varchar] (64) NOT NULL ,
	[Description] [varchar] (255) NULL ,
	[TmnFormat] [varchar] (16) NULL ,
	[VarLenSpecifierLenDef] [int] NULL ,
	[CsvFldSep] [varchar] (16) NULL ,
	[CsvEleDelim] [varchar] (16) NULL ,
	[CsvGuardChar] [varchar] (1) NULL ,
	[CsvTrimWhiteSpace] [tinyint] NULL ,
	[TagFldSep] [varchar] (16) NULL ,
	[TagEleDelim] [varchar] (16) NULL ,
	[TagGuardChar] [varchar] (1) NULL ,
	[TagDelimType] [varchar] (16) NULL ,
	[TagBotChar] [varchar] (255) NULL ,
	[TagEotChar] [varchar] (255) NULL ,
	[TagDelimLen] [int] NULL ,
	[TagTrimWhiteSpace] [tinyint] NULL ,
	[AreTagsOrdered] [tinyint] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[TagBotCharOut] [varchar] (255) NULL ,
	[TagEotCharOut] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_FieldGroup] PRIMARY KEY  CLUSTERED 
	(
		[FldGrpName]
	)
) ON [PRIMARY]
GO

PRINT '..GT_FieldGroupInStream'

CREATE TABLE [dbo].[GT_FieldGroupInStream] (
	[ExtSysName] [varchar] (64) NOT NULL ,
	[StreamName] [varchar] (64) NOT NULL ,
	[FldGrpName] [varchar] (64) NOT NULL ,
	[FldGrpCount] [int] NULL ,
	[TmnFormat] [varchar] (16) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_FieldGroupInStream] PRIMARY KEY  CLUSTERED 
	(
		[ExtSysName],
		[StreamName],
		[FldGrpName]
	)
) ON [PRIMARY]
GO

PRINT '..GT_FieldTranslationSet'

CREATE TABLE [dbo].[GT_FieldTranslationSet] (
	[FldTlnSetName] [varchar] (32) NOT NULL ,
	[Sequence] [int] NOT NULL ,
	[SortSeq] [int] NOT NULL ,
	[SrcProp] [varchar] (150) NULL ,
	[TgtProp] [varchar] (150) NULL ,
	[SrcPropDef] [varchar] (150) NULL ,
	[IsCopy] [tinyint] NOT NULL ,
	[Operator] [varchar] (255) NULL ,
	[LookupName] [varchar] (32) NULL ,
	[LookupResultPropDef] [varchar] (150) NULL ,
	[LookupResultName] [varchar] (32) NULL ,
	[ScaleType] [smallint] NULL ,
	[ScaleProp] [varchar] (150) NULL ,
	[ScaleValueDef] [int] NULL ,
	[TlnCondName] [varchar] (32) NULL ,
	[IsTlnConditional] [tinyint] NOT NULL ,
	[TlnResultNameOtherwise] [varchar] (32) NULL ,
	[CustomTlnName] [varchar] (32) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[PropTestName] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_FieldTranslationSet] PRIMARY KEY  CLUSTERED 
	(
		[FldTlnSetName],
		[Sequence]
	)
) ON [PRIMARY]
GO

PRINT '..GT_Hook'

CREATE TABLE [dbo].[GT_Hook] (
	[HookName] [varchar] (32) NOT NULL ,
	[AccessType] [varchar] (16) NOT NULL ,
	[InProc] [tinyint] NULL ,
	[HookType] [varchar] (16) NOT NULL ,
	[Description] [varchar] (255) NULL ,
	[TargetName] [varchar] (64) NOT NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	CONSTRAINT [PK_GT_Hook] PRIMARY KEY  CLUSTERED 
	(
		[HookName]
	)
) ON [PRIMARY]
GO

PRINT '..GT_LiteralToken'

CREATE TABLE [dbo].[GT_LiteralToken] (
	[LiteralName] [varchar] (32) NOT NULL ,
	[Description] [varchar] (255) NULL ,
	[LiteralValue] [varchar] (255) NOT NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_LiteralToken] PRIMARY KEY  CLUSTERED 
	(
		[LiteralName]
	)
) ON [PRIMARY]
GO

PRINT '..GT_Lookup'

CREATE TABLE [dbo].[GT_Lookup] (
	[LookupName] [varchar] (64) NOT NULL ,
	[BusServName] [varchar] (64) NOT NULL ,
	[FldGrpName] [varchar] (64) NOT NULL ,
	[SrcFldName] [varchar] (64) NOT NULL ,
	[TgtFldName] [varchar] (64) NOT NULL ,
	[CachePolicy] [varchar] (16) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_Lookup] PRIMARY KEY  CLUSTERED 
	(
		[LookupName]
	)
) ON [PRIMARY]
GO

PRINT '..GT_MessageField'

CREATE TABLE [dbo].[GT_MessageField] (
	[FldGrpName] [varchar] (64) NOT NULL ,
	[FldName] [varchar] (64) NOT NULL ,
	[Description] [varchar] (255) NULL ,
	[FldType] [varchar] (16) NOT NULL ,
	[FldFixOffset] [int] NULL ,
	[FldFixLen] [int] NULL ,
	[FldCsvOffset] [int] NULL ,
	[VarLenSpecifierExists] [tinyint] NULL ,
	[VarLenSpecifierLen] [int] NULL ,
	[EleDelim] [varchar] (16) NULL ,
	[TrimWhiteSpace] [tinyint] NULL ,
	[TagDelimType] [varchar] (16) NULL ,
	[TagBotChar] [varchar] (255) NULL ,
	[TagEotChar] [varchar] (255) NULL ,
	[TagDelimLen] [int] NULL ,
	[FldFmtNameIn] [varchar] (32) NULL ,
	[FldFmtNameOut] [varchar] (32) NULL ,
	[KeyNum] [int] NULL ,
	[KeySortSeq] [int] NULL ,
	[FldLabel] [varchar] (24) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[TruncWhiteSpaceOut] [tinyint] NULL ,
	[SuppressEmptyOutput] [tinyint] NULL ,
	[ConstantValueIn] [varchar] (255) NULL ,
	[MinParseLength] [int] NULL ,
	[MaxParseLength] [int] NULL ,
	[MinValidateLength] [int] NULL ,
	[MaxValidateLength] [int] NULL ,
	[ValidateValue] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_MessageField] PRIMARY KEY  CLUSTERED 
	(
		[FldGrpName],
		[FldName]
	)
) ON [PRIMARY]
GO



PRINT '..GT_NVP'

CREATE TABLE dbo.GT_Nvp (
	[Id] [char] (36) NOT NULL,
	[ContextId] [char] (36) NULL,
	[Name] [varchar] (50) NULL,
	[Value] [varchar] (50) NULL 
	CONSTRAINT [PK_GT_Nvp] PRIMARY KEY CLUSTERED 
	(
	[Id]
	)
) ON [PRIMARY]
GO



PRINT '..GT_ParseFiniteState'

CREATE TABLE [dbo].[GT_ParseFiniteState] (
	[StateId] [varchar] (36) NOT NULL ,
	[ExtSysName] [varchar] (64) NOT NULL ,
	[StreamName] [varchar] (64) NOT NULL ,
	[FldGrpName] [varchar] (64) NOT NULL ,
	[CurrentState] [int] NOT NULL ,
	[Sequence] [int] NOT NULL ,
	[SortSeq] [int] NOT NULL ,
	[FldGrpType] [varchar] (16) NOT NULL ,
	[FindToken] [varchar] (64) NOT NULL ,
	[FindType] [varchar] (16) NOT NULL ,
	[FindStateId] [varchar] (36) NULL ,
	[TokenAttributes] [int] NOT NULL ,
	[TokenDesignAttributes] [int] NULL ,
	[NextState] [int] NOT NULL ,
	[NextStateId] [varchar] (36) NULL ,
	[LiteralFldName] [varchar] (64) NULL ,
	[TagFldName] [varchar] (64) NULL ,
	[IsIdentifier] [tinyint] NULL ,
	[IsIdentifierConsistent] [tinyint] NULL ,
	[IdentifierStateId] [varchar] (36) NULL ,
	[IsFieldTranslated] [tinyint] NOT NULL ,
	[IsRepeatCounter] [tinyint] NULL ,
	[RepeatCountValue] [int] NULL ,
	[RepeatCountStateId] [varchar] (36) NULL ,
	[IsVarLenSpecifier] [tinyint] NULL ,
	[VarLenStateId] [varchar] (36) NULL ,
	[ViewSortSeq] [int] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[TagAttributes] [int] NULL ,
	[FldGrpFmtNameIn] [varchar] (32) NULL ,
	[FldGrpFmtNameOut] [varchar] (32) NULL ,
	[FldGrpFmtPropertyIn] [varchar] (255) NULL ,
	[MinOccurs] [int] NULL ,
	[MaxOccurs] [int] NULL ,
	[EnumSetId] [varchar] (36) NULL ,
	[TermAttributes] [int] NULL ,
	[TermSeparator] [varchar] (10) NULL ,
	[TermEscChar] [varchar] (10) NULL ,
	[TermStrDelim] [varchar] (10) NULL ,
	[CollectAttributes] [int] NULL ,
	[ContainsCount] [int] NULL ,
	[ValidateEnumSetId] [varchar] (36) NULL ,
	[ParseAttributes] [int] NULL ,
	[ConvertAttributes] [int] NULL ,
	[ValidateAttributes] [int] NULL ,
	[ParseListSep] [varchar] (10) NULL ,
	[ValidateListSep] [varchar] (10) NULL ,
	[ValMinOccurs] [int] NULL ,
	[ValMaxOccurs] [int] NULL ,
	[MinContains] [int] NULL ,
	[MaxContains] [int] NULL ,
	[ValMinContains] [int] NULL ,
	[ValMaxContains] [int] NULL ,
	[BookmarkId] [char] (36) NULL ,
	[ValPropListSetId] [varchar] (36) NULL ,
	[PostConvertAttributes] [int] NULL ,
	[ValFormatMaskIn] [varchar] (36) NULL ,
	[MinCollate] [int] NULL,
	[MaxCollate] [int] NULL,
	[ValMinCollate] [int] NULL,
	[ValMaxCollate] [int] NULL 
	CONSTRAINT [PK_GT_ParseFiniteState] PRIMARY KEY  CLUSTERED 
	(
		[StateId]
	)
) ON [PRIMARY]
GO

PRINT '..GT_ParseMethod'

CREATE TABLE [dbo].[GT_ParseMethod] (
	[StateId] [varchar] (36) NOT NULL ,
	[Sequence] [int] NOT NULL ,
	[SortSeq] [int] NOT NULL ,
	[MethodName] [varchar] (32) NOT NULL ,
	[Parameters] [varchar] (255) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_ParseMethod] PRIMARY KEY  CLUSTERED 
	(
		[StateId],
		[Sequence]
	)
) ON [PRIMARY]
GO

PRINT '..GT_PropertyTest'

CREATE TABLE [dbo].[GT_PropertyTest] (
	[PropTestName] [varchar] (32) NOT NULL ,
	[Sequence] [int] NOT NULL ,
	[SortSeq] [int] NOT NULL ,
	[IsNot] [tinyint] NOT NULL ,
	[PropLeft] [varchar] (255) NOT NULL ,
	[TestOperator] [varchar] (16) NOT NULL ,
	[PropRight] [varchar] (255) NULL ,
	[CustomTestName] [varchar] (32) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	CONSTRAINT [PK_GT_PropertyTest] PRIMARY KEY  CLUSTERED 
	(
		[PropTestName],
		[Sequence]
	)
) ON [PRIMARY]
GO

PRINT '..GT_Stream'

CREATE TABLE [dbo].[GT_Stream] (
	[ExtSysName] [varchar] (64) NOT NULL ,
	[StreamName] [varchar] (64) NOT NULL ,
	[Description] [varchar] (255) NULL ,
	[Direction] [varchar] (16) NOT NULL ,
	[CommsDevType] [varchar] (16) NOT NULL ,
	[CharacterSet] [varchar] (16) NOT NULL ,
	[TmnFormat] [varchar] (16) NOT NULL ,
	[ParseEntryPoint] [varchar] (64) NULL ,
	[ParseEntryPointIn] [varchar] (64) NULL ,
	[ParseEntryPointOut] [varchar] (64) NULL ,
	[FailureAdvanceTokenType] [varchar] (16) NULL ,
	[FailureAdvanceToken] [varchar] (16) NULL ,
	[VarLenSpecifierLenDef] [int] NULL ,
	[EndOfFile] [varchar] (16) NULL ,
	[EndOfLine] [varchar] (16) NULL ,
	[CsvFldSepDef] [varchar] (16) NULL ,
	[CsvEleDelimDef] [varchar] (16) NULL ,
	[CsvGuardCharDef] [varchar] (1) NULL ,
	[CsvTrimWhiteSpaceDef] [tinyint] NULL ,
	[TagFldSepDef] [varchar] (16) NULL ,
	[TagEleDelimDef] [varchar] (16) NULL ,
	[TagGuardCharDef] [varchar] (1) NULL ,
	[TagDelimTypeDef] [varchar] (16) NULL ,
	[TagBotCharDef] [varchar] (16) NULL ,
	[TagEotCharDef] [varchar] (16) NULL ,
	[TagDelimLenDef] [int] NULL ,
	[TagTrimWhiteSpaceDef] [tinyint] NULL ,
	[AreTagsOrderedDef] [tinyint] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[Attributes] [numeric](18, 0) NULL ,
	CONSTRAINT [PK_GT_Stream] PRIMARY KEY  CLUSTERED 
	(
		[ExtSysName],
		[StreamName]
	)
) ON [PRIMARY]
GO

PRINT '..GT_TargetCase'

CREATE TABLE [dbo].[GT_TargetCase] (
	[TgtCondName] [varchar] (32) NOT NULL ,
	[CaseName] [varchar] (32) NOT NULL ,
	[SortSeq] [int] NOT NULL ,
	[TgtResultName] [varchar] (32) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_TargetCase] PRIMARY KEY  CLUSTERED 
	(
		[TgtCondName],
		[CaseName]
	)
) ON [PRIMARY]
GO

PRINT '..GT_TargetCondition'

CREATE TABLE [dbo].[GT_TargetCondition] (
	[TgtCondName] [varchar] (32) NOT NULL ,
	[CaseName] [varchar] (32) NOT NULL ,
	[Sequence] [int] NOT NULL ,
	[SortSeq] [int] NOT NULL ,
	[PropTestName] [varchar] (32) NOT NULL ,
	[IsAbandon] [smallint] NOT NULL ,
	[IsNot] [tinyint] NOT NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_TargetCondition] PRIMARY KEY  CLUSTERED 
	(
		[TgtCondName],
		[CaseName],
		[Sequence]
	)
) ON [PRIMARY]
GO

PRINT '..GT_TargetDecision'

CREATE TABLE [dbo].[GT_TargetDecision] (
	[TgtDecisionId] [varchar] (32) NOT NULL ,
	[TgtDecisionEvent] [varchar] (32) NOT NULL ,
	[DataConvName] [varchar] (64) NOT NULL ,
	[DataSrcSysType] [varchar] (16) NOT NULL ,
	[DataSrcSysName] [varchar] (64) NOT NULL ,
	[DataSrcStreamName] [varchar] (64) NOT NULL ,
	[IsTgtConditional] [tinyint] NOT NULL ,
	[TgtCondName] [varchar] (32) NULL ,
	[TgtResultNameOtherwise] [varchar] (32) NULL ,
	[TgtResultNameDef] [varchar] (32) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[Description] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_TargetDecision] PRIMARY KEY  CLUSTERED 
	(
		[TgtDecisionId]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO

PRINT '..GT_TargetResult'

CREATE TABLE [dbo].[GT_TargetResult] (
	[TgtResultName] [varchar] (32) NOT NULL ,
	[Sequence] [int] NOT NULL ,
	[SortSeq] [int] NOT NULL ,
	[ConvTgtSysType] [varchar] (16) NOT NULL ,
	[ConvTgtSysName] [varchar] (64) NOT NULL ,
	[ConvTgtStreamName] [varchar] (64) NOT NULL ,
	[ParseEntryPoint] [varchar] (36) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[Description] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_TargetResult] PRIMARY KEY  CLUSTERED 
	(
		[TgtResultName],
		[Sequence]
	)
) ON [PRIMARY]
GO

PRINT '..GT_TranslationCase'

CREATE TABLE [dbo].[GT_TranslationCase] (
	[TlnCondName] [varchar] (32) NOT NULL ,
	[CaseName] [varchar] (32) NOT NULL ,
	[SortSeq] [int] NOT NULL ,
	[TlnResultName] [varchar] (32) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_TranslationCase] PRIMARY KEY  CLUSTERED 
	(
		[TlnCondName],
		[CaseName]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO

PRINT '..GT_TranslationCondition'

CREATE TABLE [dbo].[GT_TranslationCondition] (
	[TlnCondName] [varchar] (32) NOT NULL ,
	[CaseName] [varchar] (32) NOT NULL ,
	[Sequence] [int] NOT NULL ,
	[SortSeq] [int] NOT NULL ,
	[PropTestName] [varchar] (32) NOT NULL ,
	[IsAbandon] [smallint] NOT NULL ,
	[IsNot] [tinyint] NOT NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_TranslationCondition] PRIMARY KEY  CLUSTERED 
	(
		[TlnCondName],
		[CaseName],
		[Sequence]
	)
) ON [PRIMARY]
GO

PRINT '..GT_TranslationDecision'

CREATE TABLE [dbo].[GT_TranslationDecision] (
	[TlnDecisionId] [varchar] (32) NOT NULL ,
	[TlnDecisionEvent] [varchar] (32) NOT NULL ,
	[DataConvName] [varchar] (64) NOT NULL ,
	[DataSrcSysType] [varchar] (16) NOT NULL ,
	[DataSrcSysName] [varchar] (64) NOT NULL ,
	[DataSrcStreamName] [varchar] (64) NOT NULL ,
	[DataSrcFldGroupName] [varchar] (64) NULL ,
	[IsTlnConditional] [tinyint] NOT NULL ,
	[TlnCondName] [varchar] (32) NULL ,
	[TlnResultNameOtherwise] [varchar] (32) NULL ,
	[TlnResultNameDef] [varchar] (32) NULL ,
	[IsFlush] [tinyint] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[Description] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_TranslationDecision] PRIMARY KEY  CLUSTERED 
	(
		[TlnDecisionId]
	) 
) ON [PRIMARY]
GO

PRINT '..GT_TranslationResult'

CREATE TABLE [dbo].[GT_TranslationResult] (
	[TlnResultName] [varchar] (32) NOT NULL ,
	[Sequence] [int] NOT NULL ,
	[SortSeq] [int] NOT NULL ,
	[ConvTgtSysType] [varchar] (16) NOT NULL ,
	[ConvTgtSysName] [varchar] (64) NOT NULL ,
	[ConvTgtStreamName] [varchar] (64) NOT NULL ,
	[ConvTgtFldGrpName] [varchar] (64) NOT NULL ,
	[FldTlnSetName] [varchar] (32) NOT NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[Description] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_TranslationResult] PRIMARY KEY  CLUSTERED 
	(
		[TlnResultName],
		[Sequence]
	)
) ON [PRIMARY]
GO

PRINT '..GT_Workflow'

CREATE TABLE [dbo].[GT_Workflow] (
	[WorkflowName] [varchar] (64) NOT NULL ,
	[Description] [varchar] (255) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	CONSTRAINT [PK_GT_Workflow] PRIMARY KEY  CLUSTERED 
	(
		[WorkflowName]
	)
) ON [PRIMARY]
GO

PRINT '..UA_Adapter'

CREATE TABLE [dbo].[UA_Adapter] (
	[AdapterName] [varchar] (64) NOT NULL ,
	[AdapterType] [varchar] (16) NOT NULL ,
	[AdapterDetail] [varchar] (64) NULL ,
	[AccessType] [varchar] (16) NOT NULL ,
	[Description] [varchar] (255) NULL ,
	[TargetName] [varchar] (64) NOT NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	CONSTRAINT [PK_UA_Adapter] PRIMARY KEY  CLUSTERED 
	(
		[AdapterName]
	)
) ON [PRIMARY]
GO

PRINT '..UA_FileDetail'

CREATE TABLE [dbo].[UA_FileDetail] (
	[DetailName] [varchar] (64) NOT NULL ,
	[Directory] [varchar] (128) NULL ,
	[OutputFileName] [varchar] (64) NULL ,
	[WriteAppend] [tinyint] NULL ,
	[IsUnique] [tinyint] NULL ,
	[EndOfRecord] [varchar] (64) NULL ,
	[EndOfData] [varchar] (64) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[BinaryMode] [tinyint] NULL ,
	[UnicodeMode] [int] NULL ,
	[CodePage] [int] NULL 
	CONSTRAINT [PK_UA_FileDetail] PRIMARY KEY  CLUSTERED 
	(
		[DetailName]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO

PRINT '..UA_FtpDetail'

CREATE TABLE [dbo].[UA_FtpDetail] (
	[DetailName] [varchar] (64) NOT NULL ,
	[RemoteHost] [varchar] (64) NULL ,
	[RemoteUser] [varchar] (64) NULL ,
	[Password] [varchar] (64) NULL ,
	[RemoteDirectory] [varchar] (128) NULL ,
	[RemoteFileName] [varchar] (64) NULL ,
	[PortNumber] [int] NULL ,
	[FileNameUnique] [tinyint] NULL ,
	[BinaryTransfer] [tinyint] NULL ,
	[EndOfRecord] [varchar] (64) NULL ,
	[EndOfData] [varchar] (64) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[UnicodeMode] [int] NULL ,
	[CodePage] [int] NULL 
	CONSTRAINT [PK_UA_FtpDetail] PRIMARY KEY  CLUSTERED 
	(
		[DetailName]
	)
) ON [PRIMARY]
GO

PRINT '..UA_Location'

CREATE TABLE [dbo].[UA_Location] (
	Id char(36) NULL,
	[ExtSysName] [varchar] (64) NOT NULL ,
	[StreamName] [varchar] (64) NOT NULL ,
	[StreamEvent] [varchar] (64) NOT NULL ,
	[Location] [varchar] (64) NOT NULL ,
	[IsInward] [tinyint] NOT NULL ,
	[EndOfRecord] [varchar] (64) NULL ,
	EndOfData varchar(64) NULL,
	[Description] [varchar] (255) NULL ,
	TransactionName varchar(64) NULL,
	[AdapterName] [varchar] (64) NULL ,
	[AdapterDetail] [varchar] (64) NULL ,
	[AdapterPrimary] [tinyint] NULL ,
	[AltAdapterName] [varchar] (64) NULL ,
	[AltAdapterDetail] [varchar] (64) NULL ,
	[AltAdapterPrimary] [tinyint] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[TaskName] [varchar] (64) NOT NULL ,
	[StreamBased] [tinyint] NULL 
	CONSTRAINT [PK_UA_Location] PRIMARY KEY  CLUSTERED 
	(
		[ExtSysName],
		[StreamName],
		[StreamEvent],
		[Location],
		[TaskName]
	)
) ON [PRIMARY]
GO

PRINT '..UA_MSMQDetail'

CREATE TABLE [dbo].[UA_MSMQDetail] (
	[DetailName] [varchar] (64) NOT NULL ,
	[QueueName] [varchar] (64) NOT NULL ,
	[QueueHost] [varchar] (64) NULL ,
	[EndOfRecord] [varchar] (64) NULL ,
	[EndOfData] [varchar] (64) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT '..UA_OdbcDetail'

CREATE TABLE [dbo].[UA_OdbcDetail] (
	[DetailName] [varchar] (64) NOT NULL ,
	[DsnConnection] [varchar] (128) NULL ,
	[TableName] [varchar] (64) NULL ,
	[ComName] [varchar] (64) NULL ,
	[ComVersion] [int] NULL ,
	[ComOptions] [int] NULL ,
	[Timeout] [int] NULL ,
	[TransactionMode] [varchar] (10) NULL ,
	[ReservationMode] [varchar] (10) NULL ,
	[EndOfRecord] [varchar] (64) NULL ,
	[EndOfData] [varchar] (64) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT '..UA_Property'

CREATE TABLE [dbo].[UA_Property] (
	[DetailName] [varchar] (64) NOT NULL ,
	[PropertyId] [varchar] (64) NOT NULL ,
	[PropertyName] [varchar] (64) NOT NULL ,
	[PropertyValue] [varchar] (255) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL, 
	 PRIMARY KEY  CLUSTERED 
	(
		[DetailName],
		[PropertyId]
	) 
) ON [PRIMARY]
GO

PRINT '..UA_PropertySet'

CREATE TABLE [dbo].[UA_PropertySet] (
	[AdapterName] [varchar] (64) NOT NULL ,
	[PropertyId] [varchar] (64) NOT NULL ,
	[PropertyName] [varchar] (64) NOT NULL ,
	[Mandatory] [tinyint] NOT NULL ,
	[DefaultPropertyValue] [varchar] (255) NULL ,
	[PropertyAttributes] [int] NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
	 PRIMARY KEY  CLUSTERED 
	(
		[AdapterName],
		[PropertyId]
	)
) ON [PRIMARY]
GO

PRINT '..UA_SktDetail'

CREATE TABLE [dbo].[UA_SktDetail] (
	[DetailName] [varchar] (64) PRIMARY KEY CLUSTERED,
	[HostName] [varchar] (64) NULL ,
	[ServiceName] [varchar] (64) NULL ,
	[Listen] [tinyint] NOT NULL ,
	[ListenTimeout] [int] NULL ,
	[PortNumber] [int] NULL ,
	[BufferedRecvs] [tinyint] NOT NULL ,
	[MaxRecvBuffer] [int] NULL ,
	[EndOfRecord] [varchar] (64) NULL ,
	[EndOfData] [varchar] (64) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL ,
	[UnicodeMode] [int] NULL ,
	[CodePage] [int] NULL 
) ON [PRIMARY]
GO

PRINT '..UA_VolLoadDetail'

CREATE TABLE [dbo].[UA_VolLoadDetail] (
	[DetailName] [varchar] (64) PRIMARY KEY CLUSTERED,
	[DsnConnection] [varchar] (128) NOT NULL ,
	[TableName] [varchar] (64) NOT NULL ,
	[UserName] [varchar] (64) NULL ,
	[Password] [varchar] (64) NULL ,
	[DACRequired] [int] NULL ,
	[EndOfRecord] [varchar] (64) NULL ,
	[EndOfData] [varchar] (64) NULL ,
	[ComponentName] [varchar] (32) NULL ,
	[ProductVersion] [varchar] (16) NULL ,
	[NtkObjectId] [varchar] (50) NULL ,
	[NRSInfo] [varchar] (255) NULL 
) ON [PRIMARY]
GO

PRINT '..XML_NodeDef'

CREATE TABLE [dbo].[XML_NodeDef] (
	[id] [char] (36) NOT NULL ,
	[Name] [nvarchar] (50) NOT NULL ,
	[Description] [nvarchar] (50) NULL ,
	[Value] [nvarchar] (255) NULL ,
	[ParentId] [varchar] (36) NULL ,
	[PrevId] [varchar] (36) NULL ,
	[ChildId] [varchar] (36) NULL ,
	[NextId] [varchar] (36) NULL ,
	[NeighbourId] [varchar] (36) NULL ,
	[TypeDefId] [varchar] (36) NULL ,
	[Type] [int] NULL ,
	[longValId] [varchar] (36) NULL ,
	[NameSpaceURI] [nvarchar] (50) NULL 
) ON [PRIMARY]
GO

PRINT '..XML_NodeState'

CREATE TABLE [dbo].[XML_NodeState] (
	[StateId] [char] (36) NOT NULL ,
	[NodeDefId] [char] (36) NOT NULL 
) ON [PRIMARY]
GO

PRINT 'Populating tables...'
PRINT '..GT_Component'
SET NOCOUNT ON

INSERT INTO GT_Component (ComponentName, ProjectName, ReservationDateTime) VALUES ('xNetik', Null, '27/Feb/1998 10:11:45')

PRINT '..GT_ContextField'
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'ServiceRequest', 16, 'ServiceRequest', 1, 'ServiceRequest', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'ServiceRequest', 17, 'Cardinality', 1, 'Cardinality', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'ServiceRequest', 18, 'QualifierType', 1, 'QualifierType', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'ServiceRequest', 19, 'QualifierValue', 1, 'QualifierValue', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'ServiceRequest', 20, 'TransactionMode', 1, 'TransactionMode', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'ServiceRequest', 21, 'ReservationMode', 1, 'ReservationMode', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'ServiceRequest', 22, 'TransactionType', 1, 'TransactionType', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'ServiceRequest', 23, 'ScrollMode', 1, 'ScrollMode', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'ServiceRequest', 25, 'OverrideDsn', 1, 'OverrideDsn', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 1, 'ID', 1, 'ID', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 2, 'UserName', 1, 'UserName', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 3, 'RecordsInput', 1, 'RecordsInput', 'INTEGER', '0', 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 4, 'RecordsOutput', 1, 'RecordsOutput', 'INTEGER', '0', 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 5, 'InList', 1, 'InList', 'INTEGER', '0', 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 6, 'InError', 1, 'InError', 'INTEGER', '0', 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 7, 'ErrorMsg', 1, 'ErrorMsg', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 8, 'JobName', 1, 'JobName', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 9, 'ConversionName', 1, 'ConversionName', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 10, 'DeviceName', 1, 'DeviceName', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 11, 'SystemName', 1, 'SystemName', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 12, 'StreamName', 1, 'StreamName', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 13, 'Location', 0, 'Location', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 14, 'TimeStarted', 1, 'TimeStarted', 'DATETIME', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 15, 'TimeFinished', 1, 'TimeFinished', 'DATETIME', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 24, 'OutputFileName', 1, 'OutputFileName', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'Session', 30, 'EventRef', 0, 'EventRef', 'TEXT', Null, 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'System', 1, 'System name', 1, 'Name', 'TEXT', 'xNetik', 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'System', 2, 'System version', 1, 'Version', 'TEXT', '2.3', 'xNetik')
INSERT INTO GT_ContextField (Type, Name, SortSeq, Description, IsConstant, FieldName, FieldType, Value, ComponentName) VALUES ('xNetik', 'System', 3, 'System language', 1, 'Language', 'TEXT', 'GB', 'xNetik')

PRINT '..UA_Adapter'

INSERT INTO UA_Adapter (AdapterName, AdapterType, AdapterDetail, AccessType, Description, TargetName, ComponentName, NtkObjectId ) VALUES ('BaseActX', 'ActX', Null, 'CppDll', 'Generic ActiveX Server Adapter', 'UaSimpleActX20.dll', 'xNetik', newid() )
INSERT INTO UA_Adapter (AdapterName, AdapterType, AdapterDetail, AccessType, Description, TargetName, ComponentName, NtkObjectId) VALUES ('BaseBulkLoad', 'SQLSvrBulkLoad', Null, 'CppDll', 'SQL Server bulk load translator', 'VtSimpleVtDb20.dll', 'xNetik', newid() )
INSERT INTO UA_Adapter (AdapterName, AdapterType, AdapterDetail, AccessType, Description, TargetName, ComponentName, NtkObjectId) VALUES ('BaseFile', 'File', Null, 'CppDll', 'Generic Text File Adapter', 'UaSimpleFile20.dll', 'xNetik', newid() )
INSERT INTO UA_Adapter (AdapterName, AdapterType, AdapterDetail, AccessType, Description, TargetName, ComponentName, NtkObjectId) VALUES ('BaseFileStream', 'Standard', Null, 'COM', 'Streaming File Adapter', 'xNetik.FileStreamUa.1', 'xNetik', newid() )
INSERT INTO UA_Adapter (AdapterName, AdapterType, AdapterDetail, AccessType, Description, TargetName, ComponentName, NtkObjectId) VALUES ('BaseFmn', 'Fmn', Null, 'CppDll', 'Generic Foreman Parameter Adapter', 'UaSimpleFmn20.dll', 'xNetik', newid() )
INSERT INTO UA_Adapter (AdapterName, AdapterType, AdapterDetail, AccessType, Description, TargetName, ComponentName, NtkObjectId) VALUES ('BaseFtp', 'Ftp', Null, 'CppDll', 'Generic Ftp Adapter', 'UaSimpleFtp20.dll', 'xNetik', newid() )
INSERT INTO UA_Adapter (AdapterName, AdapterType, AdapterDetail, AccessType, Description, TargetName, ComponentName, NtkObjectId) VALUES ('BaseOdbc', 'Odbc', Null, 'CppDll', 'Generic Odbc Adapter', 'UaSimpleOdbc20.dll', 'xNetik', newid())
INSERT INTO UA_Adapter (AdapterName, AdapterType, AdapterDetail, AccessType, Description, TargetName, ComponentName, NtkObjectId) VALUES ('BaseSkt', 'Socket', Null, 'CppDll', 'Generic Socket Adapter', 'UaSimpleSkt20.dll', 'xNetik', newid() )
INSERT INTO UA_Adapter (AdapterName, AdapterType, AdapterDetail, AccessType, Description, TargetName, ComponentName, NtkObjectId) VALUES ('BaseSQLServerBCP', 'SQLSvrBCP', Null, 'CppDll', 'SQL Server block copy adapter', 'UaSimpleVolLoad20.dll', 'xNetik', newid() )
INSERT INTO UA_Adapter (AdapterName, AdapterType, AdapterDetail, AccessType, Description, TargetName, ComponentName, NtkObjectId) VALUES ('BaseXMLFile', 'Standard', Null, 'COM', 'XML file adapter', 'xNetik.XMLFileUa.1', 'xNetik', newid() )
INSERT INTO UA_Adapter (AdapterName, AdapterType, AdapterDetail, AccessType, Description, TargetName, ComponentName, NtkObjectId) VALUES ('MSMQ', 'Standard', Null, 'COM', 'MSMQ Adapter', 'xNetik.UaMsmq.2', 'xNetik', newid() )
DELETE FROM UA_Adapter WHERE AdapterName = 'MQSeries'
INSERT INTO UA_Adapter (AdapterName, AdapterType, AccessType, Description, TargetName, ComponentName) VALUES ('MQSeries', 'Standard', 'COM', 'MQ Series 5.x Adapter', 'xNetik.UaMq.1', 'xNetik')


PRINT '..UA_Property'

INSERT INTO UA_Property (DetailName, PropertyId, PropertyName) VALUES ('8BF35FFB770CD41183760050DA50C3AD', 'E44FE955-1911-D411-837A-0050DA50C3AD', 'IsUnique')
INSERT INTO UA_Property (DetailName, PropertyId, PropertyName) VALUES ('8BF35FFB770CD41183760050DA50C3AD', 'E44FE959-1911-D411-837A-0050DA50C3AD', 'XslTemplate')
INSERT INTO UA_Property (DetailName, PropertyId, PropertyName) VALUES ('8BF35FFB770CD41183760050DA50C3AD', 'E44FE960-1911-D411-837A-0050DA50C3AD', 'OutputDirectory')
INSERT INTO UA_Property (DetailName, PropertyId, PropertyName) VALUES ('8BF35FFB770CD41183760050DA50C3AD', 'E44FE963-1911-D411-837A-0050DA50C3AD', 'OutputFileName')

PRINT '..UA_PropertySet'

INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('BaseXMLFile', 'E44FE955-1911-D411-837A-0050DA50C3AD', 'IsUnique', 1, '1')
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory) VALUES ('BaseXMLFile', 'E44FE959-1911-D411-837A-0050DA50C3AD', 'XslTemplate', 1)
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory) VALUES ('BaseXMLFile', 'E44FE960-1911-D411-837A-0050DA50C3AD', 'OutputDirectory', 1)
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory) VALUES ('BaseXMLFile', 'E44FE963-1911-D411-837A-0050DA50C3AD', 'OutputFileName', 1)
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MSMQ', '0DE89D8B-EB4C-466A-8A9D-E4D94CAB75F5', 'Timeout(ms)', 1, '-1')
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MSMQ', NEWID(), 'StartTimeout', '1', '1')
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MSMQ', '3C6EF4CA-E9A2-49B0-8444-3FF17EDEA9EF', 'NotifyEOR', 1, 'Yes')
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MSMQ', '3FF31212-671D-48CC-9C93-86DD0E1E21A6', 'AppendEOR', 1, 'No')
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MSMQ', '44F66E74-F0FC-4388-8F1D-976B90E9353B', 'CodePage', 1, '0')
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory) VALUES ('MSMQ', 'A1F9DF8B-60F5-4FEC-AE68-961B0E3AC088', 'QueuePathname', 1)
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory) VALUES ('MSMQ', 'BCC394A3-C6ED-430B-BD41-14ABA36F6DC2', 'RejectQueue', 1)
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MSMQ', 'F0FF143E-492A-4943-BA08-04A2CE0D2BEA', 'Mode(M,U,B)', 1, 'U')
DELETE FROM UA_PropertySet WHERE AdapterName = 'MQSeries'
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MQSeries', NEWID(), 'ManagerName', '1', NULL)
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MQSeries', NEWID(), 'QueueName', '1', NULL)
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MQSeries', NEWID(), 'RejectQueue', '1', NULL)
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MQSeries', NEWID(), 'Mode(M,U,B,Q)', '1', 'M')
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MQSeries', NEWID(), 'CodePage', '1', '0')
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MQSeries', NEWID(), 'Timeout', '1', '-1')
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MQSeries', NEWID(), 'StartTimeout', '1', 'Yes')
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MQSeries', NEWID(), 'AppendEOR', '1', 'No')
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MQSeries', NEWID(), 'NotifyEOR', '1', 'Yes')
INSERT INTO UA_PropertySet (AdapterName, PropertyId, PropertyName, Mandatory, DefaultPropertyValue) VALUES ('MQSeries', NEWID(), 'IsMQClient', '1', 'No')

